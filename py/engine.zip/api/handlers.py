from __future__ import annotations
import math
from rti_app.catalog import get_pump, load_catalog
from rti_app.curves import drawdown_curve, inflow_rpm_curve, lift_sweep, pump_curve, rpm_sweep, setting_depth_sweep
from rti_app.estimates import estimate
from rti_app.operating_point import solve_operating_point
from rti_app.options import EngineOptions
from rti_app.pump_model import PumpCoefficients
from rti_app.report import ReportHeader, build_reports, chart_titles
from .schemas import AnalyzeRequest, CurvesRequest, EstimateRequest, PumpCatalogEntry

def _finite(value):
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, dict):
        return {k: _finite(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_finite(v) for v in value]
    return value

def catalog() -> list[PumpCatalogEntry]:
    cat = load_catalog()
    return [PumpCatalogEntry(model=p.model, series=p.series, length_in=p.length_in, stages=p.stages, gal_per_rev=p.gal_per_rev) for p in cat.pumps]

def _header(req: AnalyzeRequest) -> ReportHeader:
    if req.header is None:
        return ReportHeader()
    return ReportHeader(location=req.header.location, pad=req.header.pad, well=req.header.well)

def estimate_inputs(req: EstimateRequest) -> dict:
    well = req.well.to_well_inputs()
    est = estimate(well, req.oil_api_gravity, req.surface_earth_temp_c)
    out = est.model_dump(mode='json')
    t = est.wellhead_temp_c
    out['wellhead_temp'] = t if req.well.wellhead_temp_unit == 'C' else t * 9.0 / 5.0 + 32.0
    out['wellhead_temp_unit'] = req.well.wellhead_temp_unit
    return out

def analyze(req: AnalyzeRequest) -> dict:
    well = req.well.to_well_inputs()
    options = req.options or EngineOptions.parity()
    op = solve_operating_point(well, req.well.pump_model, alpha_override=req.alpha_override, options=options)
    header = _header(req)
    imperial, metric = build_reports(op, well, header=header, oil_api_gravity=req.oil_api_gravity, options=options)
    titles = chart_titles(well, req.well.pump_model, header)
    return _finite({'operating_point': op.model_dump(mode='json'), 'imperial_report': imperial.model_dump(mode='json'), 'metric_report': metric.model_dump(mode='json'), 'chart_titles': titles.model_dump(mode='json'), 'warnings': op.warnings})

def curves(req: CurvesRequest) -> dict:
    well = req.well.to_well_inputs()
    options = req.options or EngineOptions.parity()
    op = solve_operating_point(well, req.well.pump_model, alpha_override=req.alpha_override, options=options)
    pump = get_pump(req.well.pump_model)
    coef = PumpCoefficients(pump, well.viscosity_cp, alpha_override=req.alpha_override, options=options)
    n_lift_rows = max(int(req.lift_max_m / req.lift_step_m) + 1, 1)
    lift_rows = lift_sweep(coef, rpms=req.rpms, lift_step_m=req.lift_step_m, n_rows=n_lift_rows, options=options)
    n_rpm_rows = max(int(req.rpm_max / req.rpm_step) + 1, 1)
    rpm_rows = rpm_sweep(coef, op, rpm_step=req.rpm_step, n_rows=n_rpm_rows, options=options)
    rpms = list(req.rpms)
    lift_sweep_out = {'lift_m': [r.lift_m for r in lift_rows], 'lift_ft': [r.lift_ft for r in lift_rows], 'dp_psi': [r.dp_psi for r in lift_rows], 'torque_ftlb': [r.torque_ftlb for r in lift_rows], 'torque_nm': [r.torque_nm for r in lift_rows], 'flow_gpm': {str(rpm): [r.flow_gpm[rpm] for r in lift_rows] for rpm in rpms}, 'flow_bpd': {str(rpm): [r.flow_bpd[rpm] for r in lift_rows] for rpm in rpms}, 'flow_m3d': {str(rpm): [r.flow_m3d[rpm] for r in lift_rows] for rpm in rpms}, 'power_in_kw': {str(rpm): [r.power_in_kw[rpm] for r in lift_rows] for rpm in rpms}, 'power_in_hp': {str(rpm): [r.power_in_hp[rpm] for r in lift_rows] for rpm in rpms}, 'power_out_kw': {str(rpm): [r.power_out_kw[rpm] for r in lift_rows] for rpm in rpms}, 'efficiency': {str(rpm): [r.efficiency[rpm] for r in lift_rows] for rpm in rpms}}
    rpm_sweep_out = {'rpm': [r.rpm for r in rpm_rows], 'flow_gpm': [r.flow_gpm for r in rpm_rows], 'flow_bpd': [r.flow_bpd for r in rpm_rows], 'flow_m3d': [r.flow_m3d for r in rpm_rows]}
    pump_curve_out = pump_curve(well, coef, op, options, dp_max_psi=req.pump_curve_dp_max_psi, rpms=req.rpms, include_operating_rpm=True)
    drawdown_out = inflow_out = None
    if well.inflow is not None:
        inflow_out = inflow_rpm_curve(well, coef, options, n=req.drawdown_n)
    else:
        drawdown_out = drawdown_curve(well, coef, options, n=req.drawdown_n)
    setting_depth_out = None
    if req.setting_depths_ft and well.inflow is None:
        setting_depth_out = setting_depth_sweep(well, coef, options, depths_ft=list(req.setting_depths_ft))
    return _finite({'lift_sweep': lift_sweep_out, 'rpm_sweep': rpm_sweep_out, 'pump_curve': pump_curve_out.model_dump(mode='json'), 'drawdown': drawdown_out.model_dump(mode='json') if drawdown_out is not None else None, 'inflow_rpm': inflow_out.model_dump(mode='json') if inflow_out is not None else None, 'setting_depth': setting_depth_out.model_dump(mode='json') if setting_depth_out is not None else None, 'operating_point': op.model_dump(mode='json')})
_ROUTES = {'/estimate': (EstimateRequest, estimate_inputs), '/analyze': (AnalyzeRequest, analyze), '/curves': (CurvesRequest, curves)}

def dispatch(path: str, body: str | None=None) -> str:
    import json
    from pydantic import ValidationError
    try:
        if path == '/health':
            result = {'status': 'ok'}
        elif path == '/catalog':
            result = [p.model_dump(mode='json') for p in catalog()]
        elif path in _ROUTES:
            model, handler = _ROUTES[path]
            result = handler(model.model_validate_json(body or '{}'))
        else:
            return json.dumps({'status': 404, 'body': {'detail': 'Not Found'}})
        return json.dumps({'status': 200, 'body': result}, allow_nan=False)
    except ValidationError as exc:
        return json.dumps({'status': 422, 'body': {'detail': json.loads(exc.json(include_url=False))}})
    except KeyError as exc:
        return json.dumps({'status': 400, 'body': {'detail': str(exc.args[0] if exc.args else exc)}})
    except ValueError as exc:
        return json.dumps({'status': 400, 'body': {'detail': str(exc)}})
