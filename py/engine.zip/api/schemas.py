from __future__ import annotations
from pydantic import BaseModel, Field
from rti_app.inputs import WellInputsAsEntered
from rti_app.options import EngineOptions
from rti_app.pump_design import DesignRequest

class PumpCatalogEntry(BaseModel):
    model: str
    series: str
    length_in: float
    stages: float
    gal_per_rev: float = Field(description='Displacement, US gallons per revolution')

class ReportHeaderIn(BaseModel):
    location: str | None = None
    pad: str | None = None
    well: str | None = None

class AnalyzeRequest(BaseModel):
    well: WellInputsAsEntered
    header: ReportHeaderIn | None = None
    alpha_override: float | None = None
    oil_api_gravity: float | None = None
    options: EngineOptions | None = Field(default=None, description='Parity/physics knobs; defaults to parity mode')
    pump_design: DesignRequest | None = None

class EstimateRequest(BaseModel):
    well: WellInputsAsEntered
    oil_api_gravity: float = Field(gt=0, lt=100)
    surface_earth_temp_c: float = Field(default=10.0, description='Mean surface earth temperature, degC')

class AssumeRequest(BaseModel):
    well: dict
    oil_api_gravity: float | None = Field(default=None, gt=0, lt=100)
    surface_earth_temp_c: float = Field(default=10.0, description='Mean surface earth temperature, degC')

class OptimizeDesignRequest(BaseModel):
    well: WellInputsAsEntered
    alpha_override: float | None = None
    options: EngineOptions | None = None
    length_in: float = Field(default=220.0, gt=0, le=1000)
    max_stator_od_in: float | None = Field(default=None, gt=0)

class CurvesRequest(AnalyzeRequest):
    lift_max_m: float = Field(default=2400.0, gt=0, description='Max lift for the lift sweep, metres')
    lift_step_m: float = Field(default=5.0, gt=0)
    rpms: tuple[float, float, float, float] = (100.0, 200.0, 300.0, 400.0)
    rpm_max: float = Field(default=960.0, gt=0, description='Max RPM for the flow-vs-RPM sweep')
    rpm_step: float = Field(default=2.0, gt=0)
    pump_curve_dp_max_psi: float | None = Field(default=None, gt=0, description='Max dP for the pump curve (docs/CHART_BASIS.md #1); default 1.5x operating dP')
    drawdown_n: int = Field(default=40, gt=1, description='Number of fluid-level points for the drawdown curve')
    setting_depths_ft: tuple[float, ...] | None = Field(default=None, description='Pump depths for the setting-depth reference sweep (docs/CHART_BASIS.md); omit to skip it entirely')
