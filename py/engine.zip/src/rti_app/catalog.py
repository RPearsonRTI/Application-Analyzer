from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import yaml
from pydantic import BaseModel, Field
CATALOG_PATH = Path(__file__).with_name('catalog.yaml')

class PumpSpec(BaseModel):
    model: str
    series: str
    length_in: float = Field(gt=0)
    gal_per_rev: float = Field(gt=0)
    stage_pitch_in: float = Field(gt=0)
    stage_offset: float = 0.0
    alpha: float = Field(gt=0)
    beta1: float
    epsilon: float = Field(ge=0, description='ft·lb per psi (workbook D4)')
    gamma: float = Field(ge=0, description='ft·lb constant torque (workbook D5)')
    kappa: float = 1.28664
    beta2: float = -0.2066
    pcpump_friction_torque_ftlb: float | None = None
    pcpump_ve_at_rated_pressure: float | None = None
    flux_area_in2: float | None = None
    rotor_area_in2: float | None = None

    @property
    def axial_area_in2(self) -> float | None:
        if self.flux_area_in2 is None or self.rotor_area_in2 is None:
            return None
        return -1.0 * self.flux_area_in2 + self.rotor_area_in2

    @property
    def stages(self) -> float:
        return self.length_in / self.stage_pitch_in - self.stage_offset

    @classmethod
    def custom(cls, *, stages: float, gal_per_rev: float, alpha: float, beta: float, epsilon: float=0.0, gamma: float=0.0, length_in: float=39.37, kappa: float=1.28664, beta2: float=-0.2066) -> 'PumpSpec':
        beta1 = 2 * (beta - 1) / (1 - 2 * beta)
        return cls(model='Custom', series='Custom', length_in=length_in, gal_per_rev=gal_per_rev, stage_pitch_in=length_in / stages, stage_offset=0.0, alpha=alpha, beta1=beta1, epsilon=epsilon, gamma=gamma, kappa=kappa, beta2=beta2)

class Catalog(BaseModel):
    defaults: dict[str, float]
    pumps: list[PumpSpec]

    def get(self, model: str) -> PumpSpec:
        for p in self.pumps:
            if p.model.lower() == model.lower():
                return p
        raise KeyError(f'Unknown pump model {model!r}. Known: {[p.model for p in self.pumps]}')

    @property
    def models(self) -> list[str]:
        return [p.model for p in self.pumps]

@lru_cache(maxsize=1)
def load_catalog(path: Path | None=None) -> Catalog:
    raw = yaml.safe_load((path or CATALOG_PATH).read_text(encoding='utf-8'))
    defaults = raw.get('defaults', {})
    pumps = []
    for entry in raw['pumps']:
        entry = {'kappa': defaults.get('kappa', 1.28664), 'beta2': defaults.get('beta2', -0.2066), **entry}
        pumps.append(PumpSpec(**entry))
    return Catalog(defaults=defaults, pumps=pumps)

def get_pump(model: str) -> PumpSpec:
    return load_catalog().get(model)
