from __future__ import annotations
import math
import numpy as np
from pydantic import BaseModel
from scipy.optimize import brentq
from .units import ATM_PSI
TESTED_SEAL_DP_PSI = 50.0

class StagedGasResult(BaseModel):
    loss_gpm: float
    slip_gpm: float
    boundaries: list[int]
    weights: list[float]
    pressures_psig: list[float]
    max_seal_dp_psi: float

def _boundaries(stages: float) -> tuple[list[int], list[float]]:
    lo = max(1, math.floor(stages))
    frac = stages - math.floor(stages)
    if frac < 1e-12 or stages < 1:
        return ([lo], [1.0])
    return ([lo, lo + 1], [1.0 - frac, frac])

def _march(s1: float, g: float, pin: float, dp_tot: float, a: float, beta: float, phi: float, nb: int):
    d = [0.0]
    s = s1
    lp_prev = 0.0
    for i in range(1, nb + 1):
        if i > 1:
            lp = math.log1p(d[-1] / pin)
            s += g * math.exp(-phi * lp_prev) * -math.expm1(-phi * (lp - lp_prev))
            lp_prev = lp
        step = (s / a) ** (1.0 / beta)
        d.append(d[-1] + step)
        if not math.isfinite(d[-1]) or d[-1] > 1000.0 * dp_tot:
            return None
    return d

def _march_leak(e: float, g: float, ql: float, lam: float, pin: float, dp_tot: float, a: float, beta: float, phi: float, nb: int):
    d = [0.0]
    lp_prev = 0.0
    for _ in range(nb):
        r = e + g * -math.expm1(-phi * lp_prev)
        s = r
        for _it in range(60):
            step = (s / a) ** (1.0 / beta)
            if not math.isfinite(step) or d[-1] + step > 1000.0 * dp_tot:
                return None
            lp = math.log1p((d[-1] + step) / pin)
            qg = g * math.exp(-phi * lp)
            x = qg / (qg + ql) if qg + ql > 0.0 else 0.0
            f = 1.0 + lam * x * math.exp(phi * (lp - lp_prev))
            s_new = r / f
            if abs(s_new - s) <= 1e-13 * s:
                s = s_new
                break
            s = s_new
        step = (s / a) ** (1.0 / beta)
        d.append(d[-1] + step)
        lp_prev = math.log1p(d[-1] / pin)
    return d

def _chain(g: float, pin: float, pout: float, a: float, beta: float, nb: int, phi: float, ql: float=0.0, lam: float=0.0) -> tuple[float, list[float]]:
    dp_tot = pout - pin
    if g == 0.0:
        s1 = a * (dp_tot / nb) ** beta
        return (s1, [pin + dp_tot * i / nb for i in range(nb + 1)])
    if lam > 0.0:

        def march(u: float):
            return _march_leak(math.exp(u), g, ql, lam, pin, dp_tot, a, beta, phi, nb)
    else:

        def march(u: float):
            return _march(math.exp(u), g, pin, dp_tot, a, beta, phi, nb)

    def residual(u: float) -> float:
        d = march(u)
        return 1.0 if d is None else math.log((pin + d[-1]) / pout)
    u_hi = math.log(a * dp_tot ** beta)
    while residual(u_hi) < 0.0:
        u_hi += 2.0
        if u_hi > 50.0:
            raise ValueError('staged gas solve: no upper bracket for the excess loss')
    u_lo = u_hi - 20.0
    while residual(u_lo) > 0.0:
        u_lo -= 20.0
        if u_lo < u_hi - 700.0:
            raise ValueError('staged gas solve: no lower bracket for the excess loss')
    u = brentq(residual, u_lo, u_hi, xtol=1e-13, rtol=1e-14, maxiter=200)
    return (math.exp(u), [pin + x for x in march(u)])

def solve(gas_inlet_gpm: float, inlet_pressure_psig: float, dp_psi: float, alpha: float, beta: float, stages: float, polytropic_index: float, *, liquid_gpm: float=0.0, gas_leak: float=0.0) -> StagedGasResult:
    g = max(gas_inlet_gpm, 0.0)
    pin = inlet_pressure_psig + ATM_PSI
    nbs, ws = _boundaries(stages)
    if dp_psi <= 0.0:
        slip = math.copysign(alpha * (abs(dp_psi) / stages) ** beta, dp_psi) if dp_psi else 0.0
        return StagedGasResult(loss_gpm=g + slip, slip_gpm=slip, boundaries=nbs, weights=ws, pressures_psig=[inlet_pressure_psig, inlet_pressure_psig + dp_psi], max_seal_dp_psi=max(dp_psi, 0.0))
    a = alpha * stages ** (-beta) / sum((w * nb ** (-beta) for nb, w in zip(nbs, ws)))
    phi = 1.0 / polytropic_index
    pout = pin + dp_psi
    slip = 0.0
    profile: list[float] = []
    for nb, w in zip(nbs, ws):
        s1, p = _chain(g, pin, pout, a, beta, nb, phi, max(liquid_gpm, 0.0), gas_leak)
        slip += w * s1
        if not profile:
            profile = p
    pressures = [x - ATM_PSI for x in profile]
    max_seal = max((hi - lo for lo, hi in zip(pressures, pressures[1:])))
    return StagedGasResult(loss_gpm=g + slip, slip_gpm=slip, boundaries=nbs, weights=ws, pressures_psig=pressures, max_seal_dp_psi=max_seal)

def liquid_rate_at_speed(displaced_gpm: float, gas_per_liquid: float, inlet_pressure_psig: float, dp_psi: float, alpha: float, beta: float, stages: float, polytropic_index: float, *, gas_leak: float=0.0) -> float:

    def k(ql: float) -> float:
        return solve(ql * gas_per_liquid, inlet_pressure_psig, dp_psi, alpha, beta, stages, polytropic_index, liquid_gpm=ql, gas_leak=gas_leak).loss_gpm
    f0 = k(0.0) - displaced_gpm
    if f0 >= 0.0:
        return -f0
    return brentq(lambda ql: ql + k(ql) - displaced_gpm, 0.0, displaced_gpm, xtol=1e-10, rtol=1e-12)

def _march_many(e, g, ql, lam, pin, dp_tot, a, beta, phi, nb):
    d = np.zeros_like(e)
    lp_prev = np.zeros_like(e)
    bad = np.zeros(e.shape, dtype=bool)
    leak = bool(np.any(lam > 0.0))
    inv_beta = 1.0 / beta
    f_prev = np.ones_like(e)
    with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
        for _ in range(nb):
            r = e + g * -np.expm1(-phi * lp_prev)
            s = r / f_prev
            if leak:
                for _it in range(30):
                    step = (s / a) ** inv_beta
                    p_i = pin + d + step
                    lp = np.log(p_i / pin)
                    qg = g * np.exp(-phi * lp)
                    tot = qg + ql
                    x = np.where(tot > 0.0, qg / np.where(tot > 0.0, tot, 1.0), 0.0)
                    lex = lam * x * np.exp(phi * (lp - lp_prev))
                    h = s * (1.0 + lex) - r
                    dh = 1.0 + lex + lex * phi * x * step / (beta * p_i)
                    s_new = s - h / dh
                    s_new = np.where(s_new > 0.0, s_new, 0.5 * s)
                    done = ~(np.abs(s_new - s) > 1e-14 * s)
                    s = s_new
                    if done.all():
                        break
                f_prev = np.where(s > 0.0, r / np.where(s > 0.0, s, 1.0), 1.0)
            d = d + (s / a) ** inv_beta
            bad |= ~np.isfinite(d) | (d > 1000.0 * dp_tot)
            d = np.where(bad, 0.0, d)
            lp_prev = np.log1p(d / pin)
    return np.where(bad, np.nan, d)

def _bracketed_root(fun, lo, hi, flo, fhi, xtol, rtol, maxiter=200):
    lo, hi, flo, fhi = (lo.copy(), hi.copy(), flo.copy(), fhi.copy())
    active = np.ones(lo.shape, dtype=bool)
    x = 0.5 * (lo + hi)
    x_prev = np.full(lo.shape, np.nan)
    side = np.zeros(lo.shape, dtype=np.int8)
    s1 = np.full(lo.shape, np.inf)
    s2 = np.full(lo.shape, np.inf)
    for _ in range(maxiter):
        active &= hi - lo > xtol + rtol * np.abs(x)
        if not active.any():
            break
        idx = np.nonzero(active)[0]
        l, h, fl, fh = (lo[idx], hi[idx], flo[idx], fhi[idx])
        xs = h - fh * (h - l) / (fh - fl)
        xp = x_prev[idx]
        step = np.where(np.isnan(xp), 0.0, np.abs(xs - xp))
        bisect = step > 0.5 * s2[idx]
        xs = np.where(bisect | ~np.isfinite(xs), 0.5 * (l + h), xs)
        delta = 0.5 * (xtol + rtol * np.abs(xs))
        xs = np.clip(xs, l + delta, h - delta)
        step = np.where(np.isnan(xp), np.inf, np.abs(xs - xp))
        s2[idx], s1[idx] = (s1[idx], step)
        fx = fun(xs, idx)
        x[idx] = xs
        small = step <= 0.5 * (xtol + rtol * np.abs(xs))
        x_prev[idx] = xs
        up = fx > 0.0
        new_fl = np.where(up & (side[idx] == 1), 0.5 * fl, fl)
        new_fh = np.where(~up & (side[idx] == -1), 0.5 * fh, fh)
        hi[idx] = np.where(up, xs, h)
        fhi[idx] = np.where(up, fx, new_fh)
        lo[idx] = np.where(up, l, xs)
        flo[idx] = np.where(up, new_fl, fx)
        side[idx] = np.where(up, 1, -1)
        active[idx[small | (fx == 0.0)]] = False
    return x

def _excess_many(g, ql, lam, pin, pout, a, beta, nb, phi, u_guess=None):
    dp_tot = pout - pin
    e_out = a * (dp_tot / nb) ** beta
    u_out = np.log(e_out)
    ii = np.nonzero(g > 0.0)[0]
    if len(ii) == 0:
        return (e_out, u_out)
    G, QL, LAM, PIN, POUT, DPT = (g[ii], ql[ii], lam[ii], pin[ii], pout[ii], dp_tot[ii])

    def residual(u, idx):
        d = _march_many(np.exp(u), G[idx], QL[idx], LAM[idx], PIN[idx], DPT[idx], a, beta, phi, nb)
        return np.where(np.isnan(d), 1.0, np.log((PIN[idx] + d) / POUT[idx]))
    cold_hi = np.log(a * DPT ** beta)
    guess = np.full(len(ii), np.nan) if u_guess is None else u_guess[ii]
    warm = np.isfinite(guess)
    hi = np.where(warm, guess + 0.02, cold_hi)
    lo = np.where(warm, guess - 0.02, cold_hi - 20.0)
    step = np.where(warm, 0.1, 2.0)
    all_idx = np.arange(len(ii))
    fhi = residual(hi, all_idx)
    for _ in range(60):
        need = np.nonzero(fhi < 0.0)[0]
        if len(need) == 0:
            break
        lo[need] = hi[need]
        hi[need] = hi[need] + step[need]
        step[need] *= 2.0
        fhi[need] = residual(hi[need], need)
    else:
        raise ValueError('staged gas solve: no upper bracket for the excess loss')
    flo = residual(lo, all_idx)
    step = np.where(warm, 0.1, 20.0)
    for _ in range(60):
        need = np.nonzero(flo > 0.0)[0]
        if len(need) == 0:
            break
        hi[need], fhi[need] = (lo[need], flo[need])
        lo[need] = lo[need] - step[need]
        step[need] *= 2.0
        flo[need] = residual(lo[need], need)
    else:
        raise ValueError('staged gas solve: no lower bracket for the excess loss')
    u = _bracketed_root(residual, lo, hi, flo, fhi, xtol=1e-13, rtol=1e-14)
    e_out[ii] = np.exp(u)
    u_out[ii] = u
    return (e_out, u_out)

def loss_many(gas_inlet_gpm, inlet_pressure_psig, dp_psi, alpha, beta, stages, polytropic_index, *, liquid_gpm=0.0, gas_leak=0.0, u_guess=None):
    g, pin_g, dp, ql, lam = (np.array(v, dtype=float).ravel() for v in np.broadcast_arrays(np.asarray(gas_inlet_gpm, float), np.asarray(inlet_pressure_psig, float), np.asarray(dp_psi, float), np.asarray(liquid_gpm, float), np.asarray(gas_leak, float)))
    g, ql = (np.maximum(g, 0.0), np.maximum(ql, 0.0))
    nbs, ws = _boundaries(stages)
    k = g.copy()
    neg = dp <= 0.0
    k[neg] += np.sign(dp[neg]) * alpha * (np.abs(dp[neg]) / stages) ** beta
    us = [np.full(len(g), np.nan) for _ in nbs]
    pos = np.nonzero(~neg)[0]
    if len(pos):
        a = alpha * stages ** (-beta) / sum((w * nb ** (-beta) for nb, w in zip(nbs, ws)))
        pin = pin_g[pos] + ATM_PSI
        pout = pin + dp[pos]
        for j, (nb, w) in enumerate(zip(nbs, ws)):
            ug = None if u_guess is None else u_guess[j][pos]
            e, u = _excess_many(g[pos], ql[pos], lam[pos], pin, pout, a, beta, nb, 1.0 / polytropic_index, ug)
            k[pos] += w * e
            us[j][pos] = u
    return (k, us)

def liquid_rate_at_speed_many(displaced_gpm, gas_per_liquid, inlet_pressure_psig, dp_psi, alpha, beta, stages, polytropic_index, *, gas_leak=0.0):
    qd, gpl, pin, dp = (np.array(v, dtype=float).ravel() for v in np.broadcast_arrays(np.asarray(displaced_gpm, float), np.asarray(gas_per_liquid, float), np.asarray(inlet_pressure_psig, float), np.asarray(dp_psi, float)))
    k0, _ = loss_many(0.0 * qd, pin, dp, alpha, beta, stages, polytropic_index)
    f0 = k0 - qd
    result = -f0
    ii = np.nonzero(f0 < 0.0)[0]
    if len(ii) == 0:
        return result
    QD, GPL, PIN, DP = (qd[ii], gpl[ii], pin[ii], dp[ii])
    warm: list[np.ndarray] | None = None

    def f(ql, idx):
        nonlocal warm
        ug = None if warm is None else [w[idx] for w in warm]
        k, us = loss_many(ql * GPL[idx], PIN[idx], DP[idx], alpha, beta, stages, polytropic_index, liquid_gpm=ql, gas_leak=gas_leak, u_guess=ug)
        if warm is None:
            warm = [np.full(len(ii), np.nan) for _ in us]
        for w, u in zip(warm, us):
            w[idx] = u
        return ql + k - QD[idx]
    lo, hi = (np.zeros(len(ii)), QD.copy())
    fhi = f(hi, np.arange(len(ii)))
    result[ii] = _bracketed_root(f, lo, hi, f0[ii], fhi, xtol=1e-10, rtol=1e-12)
    return result
