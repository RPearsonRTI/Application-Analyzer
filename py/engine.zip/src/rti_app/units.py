import math
FT_PER_M = 1 / 0.3048
M_PER_FT = 0.3048
PSI_PER_FT_WATER = 0.43353
PSI_PER_M_H2O = 9.81 * 0.1450377377
M_H2O_PER_PSI = 0.70307
KPA_PER_PSI = 6.894757
PA_PER_PSI = 6894.757
GPM_PER_BPD = 42.0 / 1440.0
M3D_PER_GPM = 5.45099297
BPD_PER_GPM = 34.28571429
BPD_PER_M3D = 6.2898
BPD_PER_M3D_SWEEP = 6.29
NM_PER_FTLB = 1.3558179483
NM_PER_FTLB_AS10 = 0.3048 * 453.59237 * 9.81 / 1000
HP_PER_KW = 1.34102
KW_PER_HP = 0.7457
RPM_NM_PER_KW = 9549.0
SCF_PER_BBL_PER_SM3_M3 = 5.614583
ATM_PSI = 14.7
STD_TEMP_K = 288.0
STD_TEMP_K_ALT = 288.15

def m_to_ft(x: float) -> float:
    return x * FT_PER_M

def ft_to_m(x: float) -> float:
    return x * M_PER_FT

def c_to_f(c: float) -> float:
    return c * 9 / 5 + 32

def f_to_c(f: float) -> float:
    return (f - 32) * 5 / 9

def kpa_to_psi(x: float) -> float:
    return x / KPA_PER_PSI

def psi_to_kpa(x: float) -> float:
    return x * KPA_PER_PSI

def pa_to_psi(x: float) -> float:
    return x / PA_PER_PSI

def psi_to_pa(x: float) -> float:
    return x * PA_PER_PSI

def m3d_to_bpd(x: float) -> float:
    return x * BPD_PER_M3D

def bpd_to_m3d(x: float) -> float:
    return x / BPD_PER_M3D

def bpd_to_gpm(x: float) -> float:
    return x * GPM_PER_BPD

def gpm_to_bpd(x: float) -> float:
    return x * BPD_PER_GPM

def gpm_to_m3d(x: float) -> float:
    return x * M3D_PER_GPM

def ftlb_to_nm(x: float) -> float:
    return x * NM_PER_FTLB

def excel_round(x: float, digits: int=0) -> float:
    factor = 10.0 ** digits
    scaled = x * factor
    result = math.floor(scaled + 0.5) if scaled >= 0 else math.ceil(scaled - 0.5)
    return result / factor
