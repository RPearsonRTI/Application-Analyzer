from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, Field
from .units import NM_PER_FTLB, NM_PER_FTLB_AS10, PSI_PER_FT_WATER, STD_TEMP_K, STD_TEMP_K_ALT
VeBasis = Literal['rpm_nogas', 'rpm_actual']
HeadlineTorque = Literal['running', 'design']
SlipGasModel = Literal['netting', 'none', 'staged']
WellboreModel = Literal['workbook', 'drift_flux']
RodStringModel = Literal['none', 'soft_string']
_PARITY_DEFAULTS: dict[str, object] = {'hydraulic_power_divisor': 1550.0, 've_basis': 'rpm_nogas', 'polytropic_index': None, 'std_temp_k': STD_TEMP_K, 'nm_per_ftlb': NM_PER_FTLB_AS10, 'slip_gas_model': 'netting', 'clamp_curve_flow_at_zero': False, 'alpha_viscosity_clamp_cp': None, 'liquid_gradient_psi_per_ft': None, 'emit_envelope_warnings': False, 'headline_torque': 'running', 'staged_gas_leak': 0.0, 'wellbore_model': 'workbook', 'rod_string_model': 'none'}
_PHYSICS_DEFAULTS: dict[str, object] = {'hydraulic_power_divisor': 1714.0, 've_basis': 'rpm_actual', 'polytropic_index': 1.0, 'std_temp_k': STD_TEMP_K_ALT, 'nm_per_ftlb': NM_PER_FTLB, 'slip_gas_model': 'staged', 'clamp_curve_flow_at_zero': True, 'alpha_viscosity_clamp_cp': 100.0, 'liquid_gradient_psi_per_ft': None, 'emit_envelope_warnings': True, 'headline_torque': 'design', 'staged_gas_leak': 0.25, 'wellbore_model': 'drift_flux', 'rod_string_model': 'soft_string'}

class ResolvedOptions(BaseModel):
    mode: Literal['parity', 'physics']
    hydraulic_power_divisor: float
    ve_basis: VeBasis
    polytropic_index_override: float | None
    std_temp_k: float
    nm_per_ftlb: float
    slip_gas_model: SlipGasModel
    clamp_curve_flow_at_zero: bool
    alpha_viscosity_clamp_cp: float | None
    liquid_gradient_psi_per_ft: float | None
    emit_envelope_warnings: bool
    headline_torque: HeadlineTorque
    staged_gas_leak: float
    wellbore_model: WellboreModel
    rod_string_model: RodStringModel

class EngineOptions(BaseModel):
    mode: Literal['parity', 'physics'] = 'parity'
    hydraulic_power_divisor: float | None = None
    ve_basis: VeBasis | None = None
    polytropic_index: float | None = None
    std_temp_k: float | None = None
    nm_per_ftlb: float | None = None
    slip_gas_model: SlipGasModel | None = None
    clamp_curve_flow_at_zero: bool | None = None
    alpha_viscosity_clamp_cp: float | None = None
    liquid_gradient_psi_per_ft: float | None = None
    emit_envelope_warnings: bool | None = None
    headline_torque: HeadlineTorque | None = None
    staged_gas_leak: float | None = Field(default=None, ge=0.0)
    wellbore_model: WellboreModel | None = None
    rod_string_model: RodStringModel | None = None

    @classmethod
    def parity(cls) -> 'EngineOptions':
        return cls(mode='parity')

    @classmethod
    def physics(cls) -> 'EngineOptions':
        return cls(mode='physics')

    def resolved(self) -> ResolvedOptions:
        defaults = _PHYSICS_DEFAULTS if self.mode == 'physics' else _PARITY_DEFAULTS

        def pick(name: str):
            value = getattr(self, name)
            return defaults[name] if value is None else value
        return ResolvedOptions(mode=self.mode, hydraulic_power_divisor=pick('hydraulic_power_divisor'), ve_basis=pick('ve_basis'), polytropic_index_override=pick('polytropic_index'), std_temp_k=pick('std_temp_k'), nm_per_ftlb=pick('nm_per_ftlb'), slip_gas_model=pick('slip_gas_model'), clamp_curve_flow_at_zero=pick('clamp_curve_flow_at_zero'), alpha_viscosity_clamp_cp=pick('alpha_viscosity_clamp_cp'), liquid_gradient_psi_per_ft=pick('liquid_gradient_psi_per_ft'), emit_envelope_warnings=pick('emit_envelope_warnings'), headline_torque=pick('headline_torque'), staged_gas_leak=pick('staged_gas_leak'), wellbore_model=pick('wellbore_model'), rod_string_model=pick('rod_string_model'))
DEFAULT_OPTIONS = EngineOptions.parity()
