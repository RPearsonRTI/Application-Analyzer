from __future__ import annotations
import math
from pydantic import BaseModel
from .operating_point import WellInputs
from .units import GPM_PER_BPD
from .wellbore import G, M3S_PER_GPM, M_PER_IN, SURFACE_TENSION
INVERSION_WATER_CUT = 0.5
EARTH_CONDUCTIVITY = 1.4
EARTH_DIFFUSIVITY = 0.04
PRODUCTION_TIME_HR = 30 * 24.0
U_TUBING = 3.0
CP_WATER, CP_OIL = (1.0, 0.5)
WATER_DENSITY_LB_FT3 = 62.4

class Estimates(BaseModel):
    viscosity_cp: float
    oil_viscosity_cp: float
    water_viscosity_cp: float
    continuous_phase: str
    wellhead_temp_c: float
    relaxation_length_ft: float
    gas_through_annulus_pct: float
    liquid_velocity_m_s: float
    bubble_rise_m_s: float
    notes: list[str]

def f_from_c(t_c: float) -> float:
    return t_c * 9.0 / 5.0 + 32.0

def oil_sg(api: float) -> float:
    return 141.5 / (131.5 + api)

def dead_oil_viscosity_cp(api: float, temp_c: float) -> float:
    x = 10.0 ** (3.0324 - 0.02023 * api) * f_from_c(temp_c) ** (-1.163)
    return 10.0 ** x - 1.0

def water_viscosity_cp(temp_c: float) -> float:
    return math.exp(-3.7188 + 578.919 / (temp_c + 273.15 - 137.546))

def mixture_viscosity_cp(mu_oil: float, mu_water: float, water_cut: float) -> tuple[float, str]:
    if water_cut < INVERSION_WATER_CUT:
        return (mu_oil * (1.0 - water_cut) ** (-2.5), 'oil')
    return (mu_water * water_cut ** (-2.5), 'water')

def wellhead_temperature_c(well: WellInputs, api: float, surface_earth_temp_c: float) -> tuple[float, float]:
    wc = well.water_cut_pct / 100.0
    sg_o = oil_sg(api)
    rho = WATER_DENSITY_LB_FT3 * (wc + (1.0 - wc) * sg_o)
    w = well.desired_rate_bpd * 5.614583 * rho / 24.0
    mass_water = wc / (wc + (1.0 - wc) * sg_o)
    cp = mass_water * CP_WATER + (1.0 - mass_water) * CP_OIL
    r_to = well.tubing_od_in / 24.0
    r_wb = (well.casing_id_in / 2.0 + 1.0) / 12.0
    t_d = EARTH_DIFFUSIVITY * PRODUCTION_TIME_HR / r_wb ** 2
    f_t = math.log(math.exp(-0.2 * t_d) + (1.5 - 0.3719 * math.exp(-t_d)) * math.sqrt(t_d))
    a = w * cp / (2.0 * math.pi) * (EARTH_CONDUCTIVITY + r_to * U_TUBING * f_t) / (r_to * U_TUBING * EARTH_CONDUCTIVITY)
    length = well.pump_depth_ft
    g_g = (well.reservoir_temp_c - surface_earth_temp_c) / length
    return (surface_earth_temp_c + g_g * a * (1.0 - math.exp(-length / a)), a)

def annulus_gas_pct(well: WellInputs, api: float) -> tuple[float, float, float]:
    wc = well.water_cut_pct / 100.0
    rho_l = 1000.0 * (wc + (1.0 - wc) * oil_sg(api))
    d_o, d_i = (well.casing_id_in * M_PER_IN, well.tubing_od_in * M_PER_IN)
    vsl = well.desired_rate_bpd * GPM_PER_BPD * M3S_PER_GPM / (math.pi / 4.0 * (d_o ** 2 - d_i ** 2))
    v_inf = 1.53 * (G * SURFACE_TENSION * rho_l / rho_l ** 2) ** 0.25
    return (100.0 * v_inf / (v_inf + vsl), vsl, v_inf)

def estimate(well: WellInputs, api: float, surface_earth_temp_c: float=10.0) -> Estimates:
    t = well.reservoir_temp_c
    mu_o, mu_w = (dead_oil_viscosity_cp(api, t), water_viscosity_cp(t))
    mu, phase = mixture_viscosity_cp(mu_o, mu_w, well.water_cut_pct / 100.0)
    t_wh, a = wellhead_temperature_c(well, api, surface_earth_temp_c)
    e, vsl, v_inf = annulus_gas_pct(well, api)
    notes = [f'Viscosity at {t:.0f} degC: dead oil {mu_o:.3g} cP (Beggs-Robinson, API {api:g}), water {mu_w:.2f} cP; {phase}-continuous at {well.water_cut_pct:.0f} % water cut (inversion taken at {INVERSION_WATER_CUT:.0%}), Brinkman emulsion factor -> {mu:.3g} cP.', f'Wellhead temperature: Ramey/Hasan-Kabir with the surface earth at {surface_earth_temp_c:.0f} degC, relaxation length {a:,.0f} ft over {well.pump_depth_ft:,.0f} ft of tubing at {well.desired_rate_bpd:,.0f} BPD -> {t_wh:.0f} degC.', f'Annulus gas: liquid rises past the intake at {vsl:.2f} m/s against a bubble rise of {v_inf:.2f} m/s (Alhanati) -> {e:.0f} % of the free gas vents up the annulus, if the pump is above the perforations.']
    if mu > 100.0:
        notes.append('Above 100 cP the bubble-rise velocity, and so the annulus-gas estimate, is optimistic.')
    return Estimates(viscosity_cp=mu, oil_viscosity_cp=mu_o, water_viscosity_cp=mu_w, continuous_phase=phase, wellhead_temp_c=t_wh, relaxation_length_ft=a, gas_through_annulus_pct=e, liquid_velocity_m_s=vsl, bubble_rise_m_s=v_inf, notes=notes)
