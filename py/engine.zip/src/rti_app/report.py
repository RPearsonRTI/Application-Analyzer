from __future__ import annotations
import datetime as dt
from pydantic import BaseModel, Field
from .operating_point import OperatingPoint, WellInputs
from .options import EngineOptions
from .units import FT_PER_M, KPA_PER_PSI, NM_PER_FTLB, RPM_NM_PER_KW, SCF_PER_BBL_PER_SM3_M3, bpd_to_m3d, c_to_f, excel_round, ft_to_m
KN_PER_LBF = 0.0044482216152605

class ReportHeader(BaseModel):
    location: str | None = None
    pad: str | None = None
    well: str | None = None
    date: dt.date = Field(default_factory=dt.date.today)

class ChartTitles(BaseModel):
    metric: str
    imperial: str
    custom: str

class ImperialReport(BaseModel):
    header: ReportHeader = ReportHeader()
    pump_model: str
    oil_api_gravity: float | None = None
    water_cut_frac: float
    viscosity_cp: float
    gor_sm3_m3: float
    gas_separation_frac: float
    bottom_hole_temp_f: float
    pump_depth_ft: float
    design_rate_bpd: float
    tubing_head_pressure_psig: float
    casing_head_pressure_psig: float
    dp_psi: float
    generated_lift_m: float
    lift_ft: float
    rate_bpd: float
    rpm: float
    torque_ftlb: float
    torque_gas_ftlb: float
    torque_design_ftlb: float
    inlet_gvf: float
    inlet_pressure_psig: float
    power_hp: float
    ve: float
    ve_workbook: float
    pump_torque_ftlb: float | None = None
    rod_torque_ftlb: float | None = None
    rod_axial_load_lbf: float | None = None
    rod_top_stress_psi: float | None = None
    tubing_friction_psi: float | None = None
    inflow_fluid_level_ft: float | None = None
    inflow_intake_pressure_psig: float | None = None

class MetricReport(BaseModel):
    header: ReportHeader = ReportHeader()
    pump_model: str
    oil_api_gravity: float | None = None
    water_cut_frac: float
    viscosity_cp: float
    gor_sm3_m3: float
    gas_separation_frac: float
    bottom_hole_temp_c: float
    pump_depth_m: float
    design_rate_m3d: float
    tubing_head_pressure_kpa: float
    casing_head_pressure_kpa: float
    dp_kpa: float
    lift_m: float
    rate_m3d: float
    rpm: float
    torque_nm: float
    torque_gas_nm: float
    torque_design_nm: float
    inlet_gvf: float
    inlet_pressure_kpa: float
    power_kw: float
    ve: float
    ve_workbook: float
    pump_torque_nm: float | None = None
    rod_torque_nm: float | None = None
    rod_axial_load_kn: float | None = None
    rod_top_stress_mpa: float | None = None
    tubing_friction_kpa: float | None = None
    inflow_fluid_level_m: float | None = None
    inflow_intake_pressure_kpa: float | None = None

def build_reports(op: OperatingPoint, well: WellInputs, *, header: ReportHeader | None=None, oil_api_gravity: float | None=None, options: EngineOptions | None=None) -> tuple[ImperialReport, MetricReport]:
    hdr = header or ReportHeader()
    rods = op.rod_string_nogas if op.headline_is_design else op.rod_string
    pump_torque = op.pump_torque_nogas_ftlb if op.headline_is_design else op.pump_torque_ftlb
    has_rods = rods is not None
    has_inflow = op.inflow_intake_pressure_psig is not None
    rate_bpd = well.desired_rate_bpd
    rate_m3d = bpd_to_m3d(rate_bpd)
    imperial = ImperialReport(header=hdr, pump_model=op.pump_model, oil_api_gravity=oil_api_gravity, water_cut_frac=well.water_cut_pct / 100, viscosity_cp=well.viscosity_cp, gor_sm3_m3=well.gor_sm3_m3, gas_separation_frac=well.gas_through_annulus_pct / 100, bottom_hole_temp_f=c_to_f(well.reservoir_temp_c), pump_depth_ft=well.pump_depth_ft, design_rate_bpd=rate_bpd, tubing_head_pressure_psig=well.flowline_pressure_psig, casing_head_pressure_psig=well.casing_pressure_psig, dp_psi=op.dp_psi, generated_lift_m=op.generated_lift_m, lift_ft=op.generated_lift_m * FT_PER_M, rate_bpd=rate_bpd, rpm=op.rpm, torque_ftlb=op.torque_headline_ftlb, torque_gas_ftlb=op.torque_ftlb, torque_design_ftlb=op.torque_nogas_ftlb, inlet_gvf=op.inlet_gvf, inlet_pressure_psig=op.inlet_pressure_psig, power_hp=op.power_hp, ve=op.ve_simple, ve_workbook=op.ve_workbook, pump_torque_ftlb=pump_torque if has_rods else None, rod_torque_ftlb=rods.torque_ftlb if has_rods else None, rod_axial_load_lbf=rods.axial_load_top_lbf if has_rods else None, rod_top_stress_psi=rods.top_stress_psi if has_rods else None, tubing_friction_psi=op.tubing_friction_psi, inflow_fluid_level_ft=op.fluid_level_ft if has_inflow else None, inflow_intake_pressure_psig=op.inflow_intake_pressure_psig)
    metric = MetricReport(header=hdr, pump_model=op.pump_model, oil_api_gravity=oil_api_gravity, water_cut_frac=well.water_cut_pct / 100, viscosity_cp=well.viscosity_cp, gor_sm3_m3=well.gor_sm3_m3, gas_separation_frac=well.gas_through_annulus_pct / 100, bottom_hole_temp_c=well.reservoir_temp_c, pump_depth_m=ft_to_m(well.pump_depth_ft), design_rate_m3d=rate_m3d, tubing_head_pressure_kpa=well.flowline_pressure_psig * KPA_PER_PSI, casing_head_pressure_kpa=well.casing_pressure_psig * KPA_PER_PSI, dp_kpa=op.dp_psi * KPA_PER_PSI, lift_m=op.generated_lift_m, rate_m3d=rate_m3d, rpm=op.rpm, torque_nm=op.torque_headline_ftlb * NM_PER_FTLB, torque_gas_nm=op.torque_ftlb * NM_PER_FTLB, torque_design_nm=op.torque_nogas_ftlb * NM_PER_FTLB, inlet_gvf=op.inlet_gvf, inlet_pressure_kpa=op.inlet_pressure_psig * KPA_PER_PSI, power_kw=op.rpm * op.torque_headline_ftlb * NM_PER_FTLB / RPM_NM_PER_KW, ve=op.ve_simple, ve_workbook=op.ve_workbook, pump_torque_nm=pump_torque * NM_PER_FTLB if has_rods else None, rod_torque_nm=rods.torque_ftlb * NM_PER_FTLB if has_rods else None, rod_axial_load_kn=rods.axial_load_top_lbf * KN_PER_LBF if has_rods else None, rod_top_stress_mpa=rods.top_stress_psi * KPA_PER_PSI / 1000.0 if has_rods else None, tubing_friction_kpa=op.tubing_friction_psi * KPA_PER_PSI if op.tubing_friction_psi is not None else None, inflow_fluid_level_m=ft_to_m(op.fluid_level_ft) if has_inflow else None, inflow_intake_pressure_kpa=op.inflow_intake_pressure_psig * KPA_PER_PSI if has_inflow else None)
    return (imperial, metric)

def _r0(x: float) -> int:
    return int(excel_round(x, 0))

def chart_titles(well: WellInputs, pump_model: str, header: ReportHeader | None=None) -> ChartTitles:
    hdr = header or ReportHeader()
    parts = [p for p in (hdr.location, hdr.pad, hdr.well) if p]
    joined = ' '.join(parts)
    prefix = f'Rotoliptic {pump_model} - {joined}' if joined else f'Rotoliptic {pump_model}'
    tvd_ft = well.pump_depth_ft
    fluid_ft = well.fluid_level_ft
    whp_psi = well.flowline_pressure_psig
    csg_psi = well.casing_pressure_psig
    rate_bpd = well.desired_rate_bpd
    rate_m3d = bpd_to_m3d(rate_bpd)
    gor_sm3_m3 = well.gor_sm3_m3
    gor_scf_bbl = gor_sm3_m3 * SCF_PER_BBL_PER_SM3_M3
    watercut_pct = well.water_cut_pct
    metric_line2 = f' {_r0(ft_to_m(tvd_ft))}m TVD, {_r0(ft_to_m(fluid_ft))}m fluid from surface, {_r0(whp_psi)} psi WHP, {_r0(csg_psi)} psi Casing P,'
    metric_line3 = f'{_r0(rate_m3d)} m3/d, {_r0(gor_sm3_m3)} m3/m3 GOR, {_r0(watercut_pct)}% Watercut'
    metric_title = f'{prefix}\n{metric_line2}\n{metric_line3}'
    ft_line2 = f' {_r0(tvd_ft)}ft TVD, {_r0(fluid_ft)}ft fluid from surface, {_r0(whp_psi)} psi WHP, {_r0(csg_psi)} psi Casing P,'
    imperial_line3 = f'{_r0(rate_bpd)} bbld, {_r0(gor_scf_bbl)} scf/bbl GOR, {_r0(watercut_pct)}% Watercut'
    imperial_title = f'{prefix}\n{ft_line2}\n{imperial_line3}'
    custom_line3 = f'{_r0(rate_bpd)} bbld, {_r0(watercut_pct)}% Watercut'
    custom_title = f'{prefix}\n{ft_line2}\n{custom_line3}'
    return ChartTitles(metric=metric_title, imperial=imperial_title, custom=custom_title)
