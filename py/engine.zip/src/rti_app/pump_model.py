from __future__ import annotations
import math
from .catalog import PumpSpec
from .options import EngineOptions, ResolvedOptions

def effective_beta(beta1: float, viscosity_cp: float, beta2: float) -> float:
    return 0.5 * (1.0 + 1.0 / (1.0 + beta1 * viscosity_cp ** beta2))

def effective_alpha(alpha: float, kappa: float, viscosity_cp: float) -> float:
    return alpha * kappa ** (1.0 - math.sqrt(viscosity_cp))

def slip_gpm(dp_psi: float, stages: float, alpha_eff: float, beta_eff: float) -> float:
    if dp_psi == 0:
        return 0.0
    return math.copysign(1.0, dp_psi) * alpha_eff * (abs(dp_psi) / stages) ** beta_eff

def torque_ftlb(dp_psi: float, epsilon: float, gamma: float, gal_per_rev: float) -> float:
    return dp_psi * epsilon + gamma + 5252.0 * dp_psi * gal_per_rev / 1714.0

def power_hp(torque_ftlb_: float, rpm: float) -> float:
    return torque_ftlb_ * rpm / 5252.0

def volumetric_efficiency_simple(q_gpm: float, rpm: float, gal_per_rev: float) -> float:
    if rpm == 0:
        return 0.0
    return q_gpm / (rpm * gal_per_rev)

def volumetric_efficiency_workbook(pump: PumpSpec, alpha_eff: float, dp_per_stage_psi: float, rpm_nogas: float, slip_nogas_gpm: float) -> float:
    mu = 1.0
    exponent = 0.5 * (1.0 + 1.0 / (1.0 + 2.57143 * mu ** pump.beta2))
    numerator = alpha_eff * pump.kappa ** (1.0 - math.sqrt(mu)) * dp_per_stage_psi ** exponent
    denominator = (pump.gal_per_rev * rpm_nogas - slip_nogas_gpm) * rpm_nogas
    if denominator == 0:
        return float('nan')
    return 1.0 - numerator / denominator

class PumpCoefficients:

    def __init__(self, pump: PumpSpec, viscosity_cp: float=1.0, alpha_override: float | None=None, options: EngineOptions | ResolvedOptions | None=None):
        self.pump = pump
        self.viscosity_cp = viscosity_cp
        self.warnings: list[str] = []
        opts = options.resolved() if isinstance(options, EngineOptions) else options
        clamp_cp = opts.alpha_viscosity_clamp_cp if opts is not None else None
        mu_for_slip = viscosity_cp
        if clamp_cp is not None and viscosity_cp > clamp_cp:
            mu_for_slip = clamp_cp
            self.warnings.append(f'Viscosity {viscosity_cp:g} cP exceeds the slip-correlation clamp of {clamp_cp:g} cP; alpha and beta computed at the clamp value (see docs/PHYSICS_REVIEW.md item E).')
        self.alpha = alpha_override if alpha_override is not None else effective_alpha(pump.alpha, pump.kappa, mu_for_slip)
        self.beta = effective_beta(pump.beta1, mu_for_slip, pump.beta2)
        self.epsilon = pump.epsilon
        self.gamma = pump.gamma
        self.stages = pump.stages
        self.gal_per_rev = pump.gal_per_rev

    def slip(self, dp_psi: float) -> float:
        return slip_gpm(dp_psi, self.stages, self.alpha, self.beta)

    def torque(self, dp_psi: float) -> float:
        return torque_ftlb(dp_psi, self.epsilon, self.gamma, self.gal_per_rev)
