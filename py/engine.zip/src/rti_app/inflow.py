from __future__ import annotations
import math
from pydantic import BaseModel, Field, PrivateAttr, model_validator
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
FIT_TOLERANCE = 0.1

class InflowCurve(BaseModel):
    rate_bpd: list[float] = Field(min_length=2)
    intake_pressure_psig: list[float] = Field(min_length=2)
    reference_depth_ft: float | None = Field(default=None, gt=0, description='None = at the pump intake')
    productivity_index_bpd_psi: float | None = None
    notes: list[str] = Field(default_factory=list)
    _spline: PchipInterpolator | None = PrivateAttr(default=None)

    @model_validator(mode='after')
    def _check(self) -> 'InflowCurve':
        if len(self.rate_bpd) != len(self.intake_pressure_psig):
            raise ValueError('inflow curve: rate and pressure lists must have the same length')
        pts = sorted(zip(self.rate_bpd, self.intake_pressure_psig))
        rates = [q for q, _ in pts]
        if any((q < 0 for q in rates)) or len(set(rates)) != len(rates):
            raise ValueError('inflow curve: rates must be non-negative and distinct')
        pres = [p for _, p in pts]
        if any((b > a + 1e-09 for a, b in zip(pres, pres[1:]))):
            raise ValueError('inflow curve: pressure must not rise with rate')
        if pres[0] <= pres[-1]:
            raise ValueError('inflow curve: pressure must fall across the curve')
        self.rate_bpd, self.intake_pressure_psig = (rates, pres)
        return self

    def at_pump(self, pump_depth_ft: float, gradient_psi_per_ft: float) -> 'InflowCurve':
        if self.reference_depth_ft is None:
            return self
        shift = gradient_psi_per_ft * (self.reference_depth_ft - pump_depth_ft)
        return InflowCurve(rate_bpd=self.rate_bpd, intake_pressure_psig=[p - shift for p in self.intake_pressure_psig], productivity_index_bpd_psi=self.productivity_index_bpd_psi, notes=self.notes)

    def _interp(self) -> PchipInterpolator:
        if self._spline is None:
            self._spline = PchipInterpolator(self.rate_bpd, self.intake_pressure_psig, extrapolate=False)
        return self._spline

    def pressure_psig(self, rate_bpd: float) -> float:
        s = self._interp()
        q0, q1 = (self.rate_bpd[0], self.rate_bpd[-1])
        if rate_bpd < q0:
            return float(s(q0) + s.derivative()(q0) * (rate_bpd - q0))
        if rate_bpd > q1:
            return float(s(q1) + s.derivative()(q1) * (rate_bpd - q1))
        return float(s(rate_bpd))

    def rate_bpd_at(self, pressure_psig: float) -> float:
        lo, hi = (0.0, max(self.rate_bpd[-1], 1.0))
        f = lambda q: self.pressure_psig(q) - pressure_psig
        if f(lo) < 0:
            return float('nan')
        for _ in range(60):
            if f(hi) <= 0:
                return brentq(f, lo, hi, xtol=1e-09, rtol=1e-12)
            lo, hi = (hi, 2.0 * hi)
        return float('nan')

    @property
    def max_rate_bpd(self) -> float:
        q = self.rate_bpd_at(0.0)
        return q if math.isfinite(q) else float('nan')

class ReservoirInflow(BaseModel):
    reservoir_pressure_psig: float = Field(gt=0, description='static reservoir pressure')
    bubble_point_psig: float | None = Field(default=None, ge=0, description='None or 0: no Vogel section')
    test_pressure_psig: list[float] = Field(default_factory=list, description='producing pressures')
    test_rate_bpd: list[float] = Field(default_factory=list)
    productivity_index_bpd_psi: float | None = Field(default=None, gt=0, description='used when no test points')
    reference_depth_ft: float | None = Field(default=None, gt=0, description='None = at the pump intake')

    @model_validator(mode='after')
    def _check(self) -> 'ReservoirInflow':
        if len(self.test_pressure_psig) != len(self.test_rate_bpd):
            raise ValueError('inflow test data: each test point needs a producing pressure and a rate')
        if not self.test_rate_bpd and self.productivity_index_bpd_psi is None:
            raise ValueError('inflow test data: give at least one test point or a productivity index')
        for p, q in zip(self.test_pressure_psig, self.test_rate_bpd):
            if q <= 0:
                raise ValueError('inflow test data: test rates must be positive')
            if not 0 <= p < self.reservoir_pressure_psig:
                raise ValueError(f'inflow test data: producing pressure {p:.0f} psig must be between 0 and the static reservoir pressure {self.reservoir_pressure_psig:.0f} psig')
        return self

    @property
    def _pb(self) -> float:
        pb = self.bubble_point_psig or 0.0
        return min(pb, self.reservoir_pressure_psig)

    def shape(self, pwf_psig: float) -> float:
        pr, pb = (self.reservoir_pressure_psig, self._pb)
        if pwf_psig >= pb:
            return pr - pwf_psig
        x = pwf_psig / pb
        return pr - pb + pb / 1.8 * (1.0 - 0.2 * x - 0.8 * x * x)

    def fit(self) -> tuple[float, list[str]]:
        notes: list[str] = []
        if not self.test_rate_bpd:
            return (self.productivity_index_bpd_psi, notes)
        f = [self.shape(p) for p in self.test_pressure_psig]
        j = sum((q * fi for q, fi in zip(self.test_rate_bpd, f))) / sum((fi * fi for fi in f))
        worst = max((abs(q / (j * fi) - 1.0) for q, fi in zip(self.test_rate_bpd, f)))
        if worst > FIT_TOLERANCE:
            pts = '; '.join((f'{q:,.0f} BPD at {p:.0f} psig (fitted {j * fi:,.0f})' for p, q, fi in zip(self.test_pressure_psig, self.test_rate_bpd, f)))
            notes.append(f'The inflow test points do not lie on one IPR curve (up to {worst:.0%} off the least-squares fit): {pts}. Check that they were taken at the same reservoir pressure.')
        if self.productivity_index_bpd_psi is not None:
            gap = self.productivity_index_bpd_psi / j - 1.0
            if abs(gap) > FIT_TOLERANCE:
                notes.append(f'The given productivity index ({self.productivity_index_bpd_psi:.3g} BPD/psi) differs by {gap:+.0%} from the one fitted to the test points ({j:.3g} BPD/psi); the fit is used.')
        return (j, notes)

    def to_curve(self, n: int=80) -> InflowCurve:
        j, notes = self.fit()
        pr, pb = (self.reservoir_pressure_psig, self._pb)
        pressures = sorted({pr * i / n for i in range(n + 1)} | ({pb} if 0.0 < pb < pr else set()), reverse=True)
        return InflowCurve(rate_bpd=[j * self.shape(p) for p in pressures], intake_pressure_psig=pressures, reference_depth_ft=self.reference_depth_ft, productivity_index_bpd_psi=j, notes=notes)
