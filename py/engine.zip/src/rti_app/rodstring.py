from __future__ import annotations
import math
from pydantic import BaseModel
from .wellbore import COUPLING_LENGTH_IN, ROD_LENGTH_FT
STEEL_DENSITY = 7850.0
STEEL_LB_PER_IN3 = 0.2836
N_M_PER_FT_LB = 1.3558179483
M_PER_IN = 0.0254
M_PER_FT = 0.3048

class RodStringResult(BaseModel):
    viscous_torque_ftlb: float
    friction_torque_ftlb: float
    torque_ftlb: float
    pump_thrust_lbf: float
    rod_weight_buoyed_lbf: float
    axial_load_top_lbf: float
    compressed_length_ft: float
    top_stress_psi: float

def couette_torque_per_m(r1: float, r2: float, omega: float, rho: float, mu: float) -> float:
    if omega <= 0.0 or r1 <= 0.0:
        return 0.0
    laminar = 4.0 * math.pi * mu * omega * r1 ** 2 * r2 ** 2 / (r2 ** 2 - r1 ** 2)
    s = r2 - r1
    re = omega * r1 * s * rho / mu
    if re < 64.0:
        return laminar
    c, n = (2.0, -0.6) if re < 500.0 else (1.03, -0.5) if re < 10000.0 else (0.065, -0.2)
    cm = c * (s / r1) ** 0.3 * re ** n
    return max(laminar, cm * math.pi * rho * omega ** 2 * r1 ** 4 / 2.0)

def rod_string(*, pump_depth_ft: float, rpm: float, dp_psi: float, pump_torque_ftlb: float, axial_area_in2: float, wellhead_pressure_psig: float, rod_od_in: float, coupling_od_in: float, tubing_id_in: float, liquid_density_kg_m3: float, buoyancy_density_kg_m3: float | None=None, viscosity_cp: float, dogleg_deg_per_100ft: float, friction_coefficient: float) -> RodStringResult:
    has_couplings = coupling_od_in > rod_od_in
    share = COUPLING_LENGTH_IN / (ROD_LENGTH_FT * 12.0) if has_couplings else 0.0
    length_m = pump_depth_ft * M_PER_FT
    r_t = tubing_id_in * M_PER_IN / 2.0
    omega = rpm * 2.0 * math.pi / 60.0
    mu = viscosity_cp * 0.001
    rho = liquid_density_kg_m3
    viscous_nm = length_m * (1.0 - share) * couette_torque_per_m(rod_od_in * M_PER_IN / 2.0, r_t, omega, rho, mu)
    if has_couplings:
        viscous_nm += length_m * share * couette_torque_per_m(coupling_od_in * M_PER_IN / 2.0, r_t, omega, rho, mu)
    viscous = viscous_nm / N_M_PER_FT_LB
    body_in2 = math.pi / 4.0 * rod_od_in ** 2
    ring_in2 = math.pi / 4.0 * (coupling_od_in ** 2 - rod_od_in ** 2) if has_couplings else 0.0
    w_air = STEEL_LB_PER_IN3 * (body_in2 * 12.0 + ring_in2 * COUPLING_LENGTH_IN / ROD_LENGTH_FT)
    rho_buoy = rho if buoyancy_density_kg_m3 is None else buoyancy_density_kg_m3
    w_b = w_air * (1.0 - rho_buoy / STEEL_DENSITY)
    length_ft = pump_depth_ft
    thrust = dp_psi * axial_area_in2
    kappa = math.radians(dogleg_deg_per_100ft) / 100.0
    r_contact_ft = (coupling_od_in if has_couplings else rod_od_in) / 2.0 / 12.0
    s0 = min(max(-thrust / w_b, 0.0), length_ft) if w_b > 0 else length_ft if thrust < 0 else 0.0
    tension_integral = w_b * length_ft ** 2 / 2.0 + thrust * length_ft - 2.0 * (w_b * s0 ** 2 / 2.0 + thrust * s0)
    friction = friction_coefficient * r_contact_ft * kappa * tension_integral
    total = viscous + friction
    top_load = w_b * length_ft + thrust - wellhead_pressure_psig * body_in2
    top_stress = 0.0
    if rod_od_in > 0.0:
        sigma = top_load / body_in2
        tau = 16.0 * (pump_torque_ftlb + total) * 12.0 / (math.pi * rod_od_in ** 3)
        top_stress = math.sqrt(sigma ** 2 + 3.0 * tau ** 2)
    return RodStringResult(viscous_torque_ftlb=viscous, friction_torque_ftlb=friction, torque_ftlb=total, pump_thrust_lbf=thrust, rod_weight_buoyed_lbf=w_b * length_ft, axial_load_top_lbf=top_load, compressed_length_ft=s0, top_stress_psi=top_stress)
