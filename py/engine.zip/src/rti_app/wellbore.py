from __future__ import annotations
import math
from typing import Callable
from pydantic import BaseModel
from . import fluids
from .units import ATM_PSI
G = 9.80665
PA_PER_PSI = 6894.757293168
M_PER_FT = 0.3048
M_PER_IN = 0.0254
M3S_PER_GPM = 0.003785411784 / 60.0
GAS_SG = 0.65
AIR_MOLAR_MASS = 0.0289647
R_GAS = 8.314462618
SURFACE_TENSION = 0.06
GAS_VISCOSITY_CP = 0.012
ROUGHNESS_M = 0.0006 * M_PER_IN
STEPS_PER_1000_FT = 20
BLEND = 0.3
ROD_LENGTH_FT = 25.0
COUPLING_LENGTH_IN = 4.0

class ProfilePoint(BaseModel):
    depth_ft: float
    pressure_psig: float
    liquid_holdup: float
    gas_velocity_m_s: float
    regime: str

class ColumnResult(BaseModel):
    pressure_psig: float
    holdup_top: float
    holdup_bottom: float
    holdup_avg: float
    regimes: list[str]
    profile: list[ProfilePoint]
    friction_psi: float = 0.0

def gas_density(pressure_psig: float, temp_c: float) -> float:
    return (pressure_psig + ATM_PSI) * PA_PER_PSI * GAS_SG * AIR_MOLAR_MASS / (R_GAS * (temp_c + 273.15))

def liquid_density(gradient_psi_per_ft: float) -> float:
    return gradient_psi_per_ft * PA_PER_PSI / M_PER_FT / G

def void_fraction(vsg: float, vsl: float, d_outer_m: float, d_inner_m: float, rho_l: float, rho_g: float) -> tuple[float, str]:
    if vsg <= 0.0:
        return (0.0, 'liquid')
    drho = max(rho_l - rho_g, 1e-09)
    vm = vsg + vsl
    v_bubble = 1.53 * (G * SURFACE_TENSION * drho / rho_l ** 2) ** 0.25
    k = d_inner_m / d_outer_m
    c_taylor = 0.35 if k <= 0.0 else 0.3 + 0.22 * k
    v_taylor = c_taylor * math.sqrt(G * d_outer_m * drho / rho_l)
    a_bubbly = vsg / (1.2 * vm + v_bubble)
    a_slug = vsg / (1.2 * vm + v_taylor)
    v_bs = (0.3 * vsl + 0.25 * v_bubble) / 0.7
    w = min(max((vsg - v_bs) / (BLEND * v_bs), 0.0), 1.0)
    alpha = (1.0 - w) * a_bubbly + w * a_slug
    if vsg > v_bs:
        alpha = max(alpha, v_bs / (1.2 * (v_bs + vsl) + v_bubble))
    regime = 'bubbly' if w < 0.5 else 'churn' if a_slug > 0.52 else 'slug'
    v_ann = 3.1 * (SURFACE_TENSION * G * drho / max(rho_g, 1e-09) ** 2) ** 0.25
    w_a = min(max((vsg - v_ann) / (BLEND * v_ann), 0.0), 1.0)
    if w_a > 0.0:
        alpha = (1.0 - w_a) * alpha + w_a * vsg / vm
        if w_a >= 0.5:
            regime = 'annular'
    return (alpha, regime)

def _fanning(re: float, d_h: float) -> float:
    if re < 1e-09:
        return 0.0
    if re < 2300.0:
        return 16.0 / re
    darcy = 0.25 / math.log10(ROUGHNESS_M / (3.7 * d_h) + 5.74 / re ** 0.9) ** 2
    return darcy / 4.0

def annulus_friction_gradient(q_m3s: float, rho: float, mu_pa_s: float, d_o: float, d_i: float) -> float:
    d_h = d_o - d_i
    v = q_m3s / (math.pi / 4.0 * (d_o ** 2 - d_i ** 2))
    re = rho * abs(v) * d_h / mu_pa_s
    if 1e-09 <= re < 2300.0:
        ro, ri = (d_o / 2.0, d_i / 2.0)
        shape = ro ** 4 - ri ** 4 - ((ro ** 2 - ri ** 2) ** 2 / math.log(ro / ri) if ri > 0.0 else 0.0)
        return 8.0 * mu_pa_s * q_m3s / (math.pi * shape)
    return 2.0 * _fanning(re, d_h) * rho * v * abs(v) / d_h

def tubing_friction_gradient(q_m3s: float, rho: float, mu_pa_s: float, d_o: float, d_rod: float, d_coupling: float=0.0) -> float:
    body = annulus_friction_gradient(q_m3s, rho, mu_pa_s, d_o, d_rod)
    if d_coupling <= d_rod:
        return body
    share = COUPLING_LENGTH_IN / (ROD_LENGTH_FT * 12.0)
    coupling = annulus_friction_gradient(q_m3s, rho, mu_pa_s, d_o, d_coupling)
    ratio = (d_o ** 2 - d_coupling ** 2) / (d_o ** 2 - d_rod ** 2)
    v_c = q_m3s / (math.pi / 4.0 * (d_o ** 2 - d_coupling ** 2))
    k = 0.5 * (1.0 - ratio) + (1.0 - ratio) ** 2
    return (1.0 - share) * body + share * coupling + k * 0.5 * rho * v_c * abs(v_c) / (ROD_LENGTH_FT * M_PER_FT)

def _rk4(p0: float, z0: float, z1: float, dpdz: Callable[[float, float], float]) -> list[tuple[float, float]]:
    n = max(4, math.ceil(abs(z1 - z0) / 1000.0 * STEPS_PER_1000_FT))
    h = (z1 - z0) / n
    pts = [(z0, p0)]
    z, p = (z0, p0)
    for _ in range(n):
        k1 = dpdz(z, p)
        k2 = dpdz(z + h / 2, p + h / 2 * k1)
        k3 = dpdz(z + h / 2, p + h / 2 * k2)
        k4 = dpdz(z + h, p + h * k3)
        p += h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        z += h
        pts.append((z, p))
    return pts

def _summarise(points: list[ProfilePoint], liquid_from: int=0) -> ColumnResult:
    wet = points[liquid_from:]
    regimes: list[str] = []
    for pt in points:
        if not regimes or regimes[-1] != pt.regime:
            regimes.append(pt.regime)
    if len(wet) > 1:
        span = wet[-1].depth_ft - wet[0].depth_ft
        avg = sum((0.5 * (a.liquid_holdup + b.liquid_holdup) * (b.depth_ft - a.depth_ft) for a, b in zip(wet, wet[1:]))) / span if span > 0 else wet[-1].liquid_holdup
    else:
        avg = wet[-1].liquid_holdup
    return ColumnResult(pressure_psig=points[-1].pressure_psig, holdup_top=wet[0].liquid_holdup, holdup_bottom=wet[-1].liquid_holdup, holdup_avg=avg, regimes=regimes, profile=points)

def linear_temperature(wellhead_temp_c: float, bottom_temp_c: float, bottom_depth_ft: float) -> Callable[[float], float]:

    def temp(z_ft: float) -> float:
        return wellhead_temp_c + (bottom_temp_c - wellhead_temp_c) * min(max(z_ft / bottom_depth_ft, 0.0), 1.0)
    return temp

def annulus_column(casing_pressure_psig: float, fluid_level_ft: float, pump_depth_ft: float, vented_gas_std_gpm: float, temp_c: Callable[[float], float], casing_id_in: float, tubing_od_in: float, gradient_psi_per_ft: float, std_temp_k: float) -> ColumnResult:
    rho_l = liquid_density(gradient_psi_per_ft)
    d_o, d_i = (casing_id_in * M_PER_IN, tubing_od_in * M_PER_IN)
    area = math.pi / 4.0 * (d_o ** 2 - d_i ** 2)
    q_std = vented_gas_std_gpm * M3S_PER_GPM

    def gas_col(z: float, p: float) -> float:
        return gas_density(p, temp_c(z)) * G * M_PER_FT / PA_PER_PSI

    def state(z: float, p: float) -> tuple[float, float, str, float]:
        vsg = q_std * fluids.gas_volume_ratio(temp_c(z), p, std_temp_k) / area
        rho_g = gas_density(p, temp_c(z))
        alpha, regime = void_fraction(vsg, 0.0, d_o, d_i, rho_l, rho_g)
        return (alpha, vsg, regime, rho_g)

    def liq_col(z: float, p: float) -> float:
        alpha, _, _, rho_g = state(z, p)
        return (rho_l * (1.0 - alpha) + rho_g * alpha) * G * M_PER_FT / PA_PER_PSI
    points: list[ProfilePoint] = []
    p_level = casing_pressure_psig
    if fluid_level_ft > 0.0:
        for z, p in _rk4(casing_pressure_psig, 0.0, fluid_level_ft, gas_col):
            points.append(ProfilePoint(depth_ft=z, pressure_psig=p, liquid_holdup=0.0, gas_velocity_m_s=0.0, regime='gas'))
        p_level = points[-1].pressure_psig
    first_wet = len(points)
    for z, p in _rk4(p_level, fluid_level_ft, pump_depth_ft, liq_col):
        alpha, vsg, regime, _ = state(z, p)
        points.append(ProfilePoint(depth_ft=z, pressure_psig=p, liquid_holdup=1.0 - alpha, gas_velocity_m_s=vsg, regime=regime))
    return _summarise(points, first_wet)

def tubing_column(flowline_pressure_psig: float, pump_depth_ft: float, liquid_gpm: float, gas_std_gpm: float, temp_c: Callable[[float], float], tubing_id_in: float, rod_od_in: float, gradient_psi_per_ft: float, viscosity_cp: float, std_temp_k: float, coupling_od_in: float=0.0) -> ColumnResult:
    rho_l = liquid_density(gradient_psi_per_ft)
    d_o, d_i, d_c = (tubing_id_in * M_PER_IN, rod_od_in * M_PER_IN, coupling_od_in * M_PER_IN)
    area = math.pi / 4.0 * (d_o ** 2 - d_i ** 2)
    vsl = liquid_gpm * M3S_PER_GPM / area
    q_std = gas_std_gpm * M3S_PER_GPM

    def state(z: float, p: float) -> tuple[float, float, str, float]:
        vsg = q_std * fluids.gas_volume_ratio(temp_c(z), p, std_temp_k) / area
        rho_g = gas_density(p, temp_c(z))
        alpha, regime = void_fraction(vsg, vsl, d_o, d_i, rho_l, rho_g)
        return (alpha, vsg, regime, rho_g)

    def friction(vsg: float, rho_g: float) -> float:
        vm = vsg + vsl
        lam = vsl / vm if vm > 0 else 1.0
        rho_n = rho_l * lam + rho_g * (1.0 - lam)
        mu_n = (viscosity_cp * lam + GAS_VISCOSITY_CP * (1.0 - lam)) * 0.001
        return tubing_friction_gradient(vm * area, rho_n, mu_n, d_o, d_i, d_c)

    def dpdz(z: float, p: float) -> float:
        alpha, vsg, _, rho_g = state(z, p)
        return ((rho_l * (1.0 - alpha) + rho_g * alpha) * G + friction(vsg, rho_g)) * M_PER_FT / PA_PER_PSI
    points = []
    grads = []
    for z, p in _rk4(flowline_pressure_psig, 0.0, pump_depth_ft, dpdz):
        alpha, vsg, regime, rho_g = state(z, p)
        points.append(ProfilePoint(depth_ft=z, pressure_psig=p, liquid_holdup=1.0 - alpha, gas_velocity_m_s=vsg, regime=regime))
        grads.append(friction(vsg, rho_g) * M_PER_FT / PA_PER_PSI)
    result = _summarise(points)
    result.friction_psi = sum((0.5 * (g0 + g1) * (b.depth_ft - a.depth_ft) for g0, g1, a, b in zip(grads, grads[1:], points, points[1:])))
    return result
