from __future__ import annotations
from .units import ATM_PSI, STD_TEMP_K, STD_TEMP_K_ALT

def gas_volume_ratio(temp_c: float, pressure_psig: float, std_temp_k: float=STD_TEMP_K) -> float:
    return ATM_PSI * (temp_c + 273.15) / (std_temp_k * (ATM_PSI + pressure_psig))

def inlet_gas_compression_ratio(reservoir_temp_c: float, inlet_pressure_psig: float) -> float:
    return gas_volume_ratio(reservoir_temp_c, inlet_pressure_psig, STD_TEMP_K_ALT)

def gas_liquid_ratio(gor_sm3_m3: float, water_cut_pct: float) -> float:
    return gor_sm3_m3 * (1.0 - water_cut_pct / 100.0)

def inlet_gas_liquid_ratio(gor_sm3_m3: float, water_cut_pct: float, gas_through_annulus_pct: float) -> float:
    return gas_liquid_ratio(gor_sm3_m3, water_cut_pct) * (1.0 - gas_through_annulus_pct / 100.0)

def gas_volume_fraction(volume_ratio: float, glr: float) -> float:
    x = volume_ratio * glr
    return x / (1.0 + x)

def oil_volume_fraction(glr: float, temp_c: float, pressure_psig: float, std_temp_k: float=STD_TEMP_K) -> float:
    return 1.0 / (1.0 + glr * gas_volume_ratio(temp_c, pressure_psig, std_temp_k))

def polytropic_volume_ratio(inlet_pressure_psig: float, dp_psi: float, polytropic_index: float) -> float:
    return ((ATM_PSI + inlet_pressure_psig) / (ATM_PSI + inlet_pressure_psig + dp_psi)) ** (1.0 / polytropic_index)

def discharge_oil_volume_fraction(glr: float, reservoir_temp_c: float, inlet_pressure_psig: float, dp_psi: float, polytropic_index: float, std_temp_k: float=STD_TEMP_K) -> float:
    r_in = gas_volume_ratio(reservoir_temp_c, inlet_pressure_psig, std_temp_k)
    return 1.0 / (1.0 + polytropic_volume_ratio(inlet_pressure_psig, dp_psi, polytropic_index) * glr * r_in)
