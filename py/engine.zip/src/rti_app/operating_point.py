from __future__ import annotations
from pydantic import BaseModel, Field, model_validator
from scipy.optimize import brentq
from . import fluids, rodstring, staged_gas, wellbore
from .catalog import PumpSpec, get_pump
from .inflow import InflowCurve
from .options import EngineOptions, ResolvedOptions
from .pump_model import PumpCoefficients, power_hp, volumetric_efficiency_simple, volumetric_efficiency_workbook
from .units import GPM_PER_BPD, M_H2O_PER_PSI, PSI_PER_FT_WATER
GAS_LOCK_LIKELY_GVF = 0.9
GAS_LOCK_RISK_GVF = 0.8
GAS_LOCK_RISK_DP_PER_STAGE_PSI = 20.0
GAS_LOCK_RISK_RPM = 150.0
ROD_STRESS_WARN_PSI = 85000.0

class WellInputs(BaseModel):
    pump_depth_ft: float = Field(gt=0, description='Inputs!C13 (TVD)')
    fluid_level_ft: float = Field(ge=0, description='Inputs!C14, from surface')
    flowline_pressure_psig: float = Field(ge=0, description='Inputs!C15')
    casing_pressure_psig: float = Field(ge=0, description='Inputs!C16')
    desired_rate_bpd: float = Field(gt=0, description='Inputs!C17')
    viscosity_cp: float = Field(gt=0, default=1.0, description='Inputs!C18')
    water_cut_pct: float = Field(ge=0, le=100, description='Inputs!C19')
    gor_sm3_m3: float = Field(ge=0, description='Inputs!C20')
    gas_through_annulus_pct: float = Field(ge=0, le=100, description='Inputs!C21')
    reservoir_temp_c: float = Field(description='Inputs!C22')
    wellhead_temp_c: float = Field(description='Inputs!C23')
    polytropic_index: float = Field(default=1.4, gt=0, description='AE5')
    tubing_id_in: float = Field(default=2.441, gt=0, description='tubing inside diameter, in')
    tubing_od_in: float = Field(default=2.875, gt=0, description='tubing outside diameter, in')
    casing_id_in: float = Field(default=4.892, gt=0, description='casing inside diameter, in')
    rod_od_in: float = Field(default=1.0, ge=0, description='rod (coupling-free body) diameter, in; 0 = rodless')
    coupling_od_in: float = Field(default=2.0, ge=0, description='rod coupling OD, in; <= rod_od_in = continuous rod')
    dogleg_severity_deg_per_100ft: float = Field(default=1.0, ge=0, description='assumed uniform tortuosity')
    rod_tubing_friction: float = Field(default=0.2, ge=0, description='rod-tubing friction coefficient')
    inflow: InflowCurve | None = None

    @model_validator(mode='after')
    def _check_geometry(self) -> 'WellInputs':
        if not self.rod_od_in < self.tubing_id_in < self.tubing_od_in < self.casing_id_in:
            raise ValueError('need rod_od_in < tubing_id_in < tubing_od_in < casing_id_in')
        if self.coupling_od_in >= self.tubing_id_in:
            raise ValueError('need coupling_od_in < tubing_id_in (a coupling OD <= rod_od_in means a continuous rod)')
        return self

    @model_validator(mode='after')
    def _check_submergence(self) -> 'WellInputs':
        if self.fluid_level_ft > self.pump_depth_ft:
            raise ValueError(f'fluid_level_ft ({self.fluid_level_ft}) must be <= pump_depth_ft ({self.pump_depth_ft})')
        return self

class OperatingPoint(BaseModel):
    pump_model: str
    warnings: list[str] = Field(default_factory=list)
    inlet_glr: float
    oil_fraction_casing_interface: float
    oil_fraction_inlet: float
    oil_fraction_casing_avg: float
    oil_fraction_wellhead: float
    oil_fraction_discharge: float
    oil_fraction_column_avg: float
    inlet_pressure_psig: float
    discharge_pressure_psig: float
    dp_psi: float
    dp_nogas_psi: float
    inlet_gvf: float
    outlet_gvf: float
    gas_ratio_inlet: float
    gas_ratio_outlet: float
    gas_rate_std_gpm: float
    gas_rate_inlet_gpm: float
    gas_rate_discharge_gpm: float
    slip_nogas_gpm: float
    slip_final_gpm: float
    liquid_rate_gpm: float
    rpm: float
    rpm_nogas: float
    torque_ftlb: float
    torque_nogas_ftlb: float
    torque_nogas_nm: float
    torque_headline_ftlb: float
    headline_is_design: bool = False
    pump_torque_ftlb: float
    pump_torque_nogas_ftlb: float
    rod_string: rodstring.RodStringResult | None = None
    rod_string_nogas: rodstring.RodStringResult | None = None
    tubing_friction_psi: float | None = None
    tubing_friction_nogas_psi: float | None = None
    power_hp: float
    power_nogas_hp: float
    ve_workbook: float
    ve_simple: float
    polytropic_index: float = 1.4
    fluid_level_ft: float | None = None
    inflow_intake_pressure_psig: float | None = None
    stage_pressures_psig: list[float] | None = None
    tubing_profile: list[wellbore.ProfilePoint] | None = None
    annulus_profile: list[wellbore.ProfilePoint] | None = None
    generated_lift_m: float
    fluid_head_psi: float
    alpha_eff: float
    beta_eff: float
    stages: float
    gal_per_rev: float

def _solve_inlet(well: WellInputs, glr_in: float, gradient_psi_per_ft: float, std_temp_k: float, tol: float=1e-12, max_iter: int=200) -> tuple[float, float, float, float]:
    t3 = fluids.oil_volume_fraction(glr_in, well.reservoir_temp_c, well.casing_pressure_psig, std_temp_k)
    submergence_head = (well.pump_depth_ft - well.fluid_level_ft) * gradient_psi_per_ft
    t5 = t3
    for _ in range(max_iter):
        p_inlet_guess = t5 * submergence_head + well.casing_pressure_psig
        t4 = fluids.oil_volume_fraction(glr_in, well.reservoir_temp_c, p_inlet_guess, std_temp_k)
        t5_new = 0.5 * (t3 + t4)
        if abs(t5_new - t5) < tol:
            t5 = t5_new
            break
        t5 = t5_new
    t4 = fluids.oil_volume_fraction(glr_in, well.reservoir_temp_c, t5 * submergence_head + well.casing_pressure_psig, std_temp_k)
    t6 = submergence_head * t5 + well.casing_pressure_psig
    return (t3, t4, t5, t6)

def _solve_dp(well: WellInputs, glr_in: float, p_inlet: float, fluid_head_psi: float, t7: float, dp_nogas: float, polytropic_index: float, std_temp_k: float, tol: float=1e-12, max_iter: int=500) -> tuple[float, float, float]:
    dp = dp_nogas
    for _ in range(max_iter):
        try:
            t8 = fluids.discharge_oil_volume_fraction(glr_in, well.reservoir_temp_c, p_inlet, dp, polytropic_index, std_temp_k)
        except (ValueError, ZeroDivisionError, OverflowError):
            return (float('nan'), float('nan'), dp_nogas)
        t9 = 0.5 * (t8 + t7)
        dp_new = fluid_head_psi * t9 + well.flowline_pressure_psig - p_inlet
        if abs(dp_new - dp) < tol:
            dp = dp_new
            break
        dp = dp_new
    t8 = fluids.discharge_oil_volume_fraction(glr_in, well.reservoir_temp_c, p_inlet, dp, polytropic_index, std_temp_k)
    t9 = 0.5 * (t8 + t7)
    return (t8, t9, dp)

def _intake_pressure(well: WellInputs, opts: ResolvedOptions, gradient: float, glr_in: float, q_gpm: float) -> float:
    if opts.wellbore_model == 'drift_flux':
        temp = wellbore.linear_temperature(well.wellhead_temp_c, well.reservoir_temp_c, well.pump_depth_ft)
        vented_std_gpm = q_gpm * fluids.gas_liquid_ratio(well.gor_sm3_m3, well.water_cut_pct) * well.gas_through_annulus_pct / 100.0
        return wellbore.annulus_column(well.casing_pressure_psig, well.fluid_level_ft, well.pump_depth_ft, vented_std_gpm, temp, well.casing_id_in, well.tubing_od_in, gradient, opts.std_temp_k).pressure_psig
    return _solve_inlet(well, glr_in, gradient, opts.std_temp_k)[3]

def _level_from_inflow(well: WellInputs, opts: ResolvedOptions, gradient: float, glr_in: float, q_gpm: float, warnings: list[str]) -> tuple[WellInputs, float]:
    target = well.inflow.pressure_psig(well.desired_rate_bpd)

    def intake(level: float) -> float:
        return _intake_pressure(well.model_copy(update={'fluid_level_ft': level}), opts, gradient, glr_in, q_gpm)
    p_full, p_off = (intake(0.0), intake(well.pump_depth_ft))
    if target >= p_full:
        level = 0.0
        warnings.append(f'The inflow curve gives {target:.0f} psig at the pump intake at this rate, more than a liquid column to surface ({p_full:.0f} psig): the well would flow. Fluid level set to surface.')
    elif target <= p_off:
        level = well.pump_depth_ft
        q_off = well.inflow.rate_bpd_at(p_off)
        reach = f'it reaches that pressure only up to about {q_off:,.0f} BPD' if q_off == q_off else f'even at zero rate it gives only {well.inflow.pressure_psig(0.0):.0f} psig'
        aof = well.inflow.max_rate_bpd
        gives = f"The desired rate is above the inflow curve's absolute open flow (about {aof:,.0f} BPD), so its intake pressure would be" if target < 0.0 and aof == aof else f'The inflow curve gives {target:.0f} psig intake at the desired rate,'
        warnings.append(f'{gives} below the pumped-off intake pressure of {p_off:.0f} psig (casing pressure plus the annulus gas column); {reach}. The pump would pump off. Fluid level set to the pump, so the intake pressure is higher than the inflow curve allows.')
    else:
        level = brentq(lambda z: intake(z) - target, 0.0, well.pump_depth_ft, xtol=0.001)
    return (well.model_copy(update={'fluid_level_ft': level}), target)

def solve_operating_point(well: WellInputs, pump: PumpSpec | str, *, alpha_override: float | None=None, options: EngineOptions | None=None) -> OperatingPoint:
    opts = (options or EngineOptions.parity()).resolved()
    if isinstance(pump, str):
        pump = get_pump(pump)
    coef = PumpCoefficients(pump, well.viscosity_cp, alpha_override=alpha_override, options=opts)
    warnings: list[str] = list(coef.warnings)
    gradient = opts.liquid_gradient_psi_per_ft if opts.liquid_gradient_psi_per_ft is not None else PSI_PER_FT_WATER
    polytropic_index = opts.polytropic_index_override if opts.polytropic_index_override is not None else well.polytropic_index
    q_gpm = well.desired_rate_bpd * GPM_PER_BPD
    glr_in = fluids.inlet_gas_liquid_ratio(well.gor_sm3_m3, well.water_cut_pct, well.gas_through_annulus_pct)
    fluid_head = well.pump_depth_ft * gradient
    inflow_target = None
    if well.inflow is not None:
        well = well.model_copy(update={'inflow': well.inflow.at_pump(well.pump_depth_ft, gradient)})
        warnings.extend(well.inflow.notes)
        well, inflow_target = _level_from_inflow(well, opts, gradient, glr_in, q_gpm, warnings)
    tubing = tubing_nogas = annulus = None
    if opts.wellbore_model == 'drift_flux':
        temp = wellbore.linear_temperature(well.wellhead_temp_c, well.reservoir_temp_c, well.pump_depth_ft)
        vented_std_gpm = q_gpm * fluids.gas_liquid_ratio(well.gor_sm3_m3, well.water_cut_pct) * well.gas_through_annulus_pct / 100.0
        annulus = wellbore.annulus_column(well.casing_pressure_psig, well.fluid_level_ft, well.pump_depth_ft, vented_std_gpm, temp, well.casing_id_in, well.tubing_od_in, gradient, opts.std_temp_k)
        tubing = wellbore.tubing_column(well.flowline_pressure_psig, well.pump_depth_ft, q_gpm, q_gpm * glr_in, temp, well.tubing_id_in, well.rod_od_in, gradient, well.viscosity_cp, opts.std_temp_k, well.coupling_od_in)
        tubing_nogas = wellbore.tubing_column(well.flowline_pressure_psig, well.pump_depth_ft, q_gpm, 0.0, temp, well.tubing_id_in, well.rod_od_in, gradient, well.viscosity_cp, opts.std_temp_k, well.coupling_od_in)
        t3, t4, t5, p_inlet = (annulus.holdup_top, annulus.holdup_bottom, annulus.holdup_avg, annulus.pressure_psig)
        p_discharge_nogas = tubing_nogas.pressure_psig
        dp_nogas = p_discharge_nogas - p_inlet
        t7, t8, t9 = (tubing.holdup_top, tubing.holdup_bottom, tubing.holdup_avg)
        dp = tubing.pressure_psig - p_inlet
    else:
        t3, t4, t5, p_inlet = _solve_inlet(well, glr_in, gradient, opts.std_temp_k)
        p_discharge_nogas = fluid_head + well.flowline_pressure_psig
        dp_nogas = p_discharge_nogas - p_inlet
        t7 = fluids.oil_volume_fraction(glr_in, well.wellhead_temp_c, well.flowline_pressure_psig, opts.std_temp_k)
        t8, t9, dp = _solve_dp(well, glr_in, p_inlet, fluid_head, t7, dp_nogas, polytropic_index, opts.std_temp_k)
    r_in = fluids.inlet_gas_compression_ratio(well.reservoir_temp_c, p_inlet)
    r_out = r_in * fluids.polytropic_volume_ratio(p_inlet, dp, polytropic_index)
    gvf_in = fluids.gas_volume_fraction(r_in, glr_in)
    gvf_out = fluids.gas_volume_fraction(r_out, glr_in)
    slip_nogas = coef.slip(dp)
    q_gas_std = q_gpm * glr_in
    q_gas_in = q_gas_std * fluids.gas_volume_ratio(well.reservoir_temp_c, p_inlet, opts.std_temp_k)
    q_gas_out = q_gas_in * fluids.polytropic_volume_ratio(p_inlet, dp, polytropic_index)
    stage_pressures = None
    if opts.slip_gas_model == 'netting':
        slip_final = max(slip_nogas - (q_gas_in - q_gas_out), 0.0)
    elif opts.slip_gas_model == 'none':
        slip_final = slip_nogas
    else:
        staged = staged_gas.solve(q_gas_in, p_inlet, dp, coef.alpha, coef.beta, coef.stages, polytropic_index, liquid_gpm=q_gpm, gas_leak=opts.staged_gas_leak)
        slip_final = staged.slip_gpm
        stage_pressures = staged.pressures_psig
        if q_gas_in > 0 and staged.max_seal_dp_psi > 2.0 * staged_gas.TESTED_SEAL_DP_PSI:
            warnings.append(f'Staged gas model puts {staged.max_seal_dp_psi:.0f} psi across one seal; the slip law was validated to about {staged_gas.TESTED_SEAL_DP_PSI:.0f} psi per seal (docs/INVESTIGATION_gvf_dynamics.md).')
    rpm = (q_gas_in + q_gpm + slip_final) / coef.gal_per_rev
    pump_torque = coef.torque(dp)
    dp_per_stage_nogas = dp_nogas / coef.stages
    slip_nogas_block = coef.slip(dp_nogas)
    rpm_nogas = (slip_nogas_block + q_gpm) / coef.gal_per_rev
    pump_torque_nogas = coef.torque(dp_nogas)
    rods = rods_nogas = None
    torque, torque_nogas = (pump_torque, pump_torque_nogas)
    if opts.rod_string_model == 'soft_string' and well.rod_od_in > 0:
        common = dict(pump_depth_ft=well.pump_depth_ft, axial_area_in2=pump.axial_area_in2 or 0.0, wellhead_pressure_psig=well.flowline_pressure_psig, rod_od_in=well.rod_od_in, coupling_od_in=well.coupling_od_in, tubing_id_in=well.tubing_id_in, liquid_density_kg_m3=wellbore.liquid_density(gradient), viscosity_cp=well.viscosity_cp, dogleg_deg_per_100ft=well.dogleg_severity_deg_per_100ft, friction_coefficient=well.rod_tubing_friction)
        rods = rodstring.rod_string(rpm=rpm, dp_psi=dp, pump_torque_ftlb=pump_torque, **common)
        rods_nogas = rodstring.rod_string(rpm=rpm_nogas, dp_psi=dp_nogas, pump_torque_ftlb=pump_torque_nogas, **common)
        torque += rods.torque_ftlb
        torque_nogas += rods_nogas.torque_ftlb
    power_nogas = power_hp(torque_nogas, rpm_nogas)
    torque_headline = torque if opts.headline_torque == 'running' else torque_nogas
    ve_wb = volumetric_efficiency_workbook(pump, coef.alpha, dp_per_stage_nogas, rpm_nogas, slip_nogas_block)
    ve_rpm_basis = rpm if opts.ve_basis == 'rpm_actual' else rpm_nogas
    ve_simple = volumetric_efficiency_simple(q_gpm, ve_rpm_basis, coef.gal_per_rev)
    if opts.emit_envelope_warnings:
        dp_per_stage = dp / coef.stages
        if gvf_in > GAS_LOCK_LIKELY_GVF:
            warnings.append(f'Inlet GVF {gvf_in:.1%} is above ~{GAS_LOCK_LIKELY_GVF:.0%}: gas lock or surging is likely. Rotoliptic loop tests were unstable here on every pump tested, and the prediction is optimistic (docs/INVESTIGATION_gvf_dynamics.md, gas-lock onset).')
        elif gvf_in > GAS_LOCK_RISK_GVF and (dp_per_stage > GAS_LOCK_RISK_DP_PER_STAGE_PSI or rpm < GAS_LOCK_RISK_RPM):
            reason = f'{dp_per_stage:.0f} psi/stage' if dp_per_stage > GAS_LOCK_RISK_DP_PER_STAGE_PSI else f'{rpm:.0f} RPM'
            warnings.append(f'Inlet GVF {gvf_in:.1%} at {reason} is outside the range the tested Rotoliptic pumps pumped stably (above ~{GAS_LOCK_RISK_GVF:.0%} GVF with more than {GAS_LOCK_RISK_DP_PER_STAGE_PSI:.0f} psi/stage or below {GAS_LOCK_RISK_RPM:.0f} RPM): risk of gas lock or surging (docs/INVESTIGATION_gvf_dynamics.md, gas-lock onset).')
        if annulus is not None and any((r in ('churn', 'annular') for r in annulus.regimes)):
            warnings.append(f'Casing annulus above the pump is in churn/annular flow (vented gas velocity {max((pt.gas_velocity_m_s for pt in annulus.profile)):.1f} m/s): the column is foamy, the acoustic fluid level is uncertain and the intake pressure is sensitive to it (PHYSICS_REVIEW item R).')
        if tubing is not None and well.viscosity_cp > 100.0:
            warnings.append(f'Drift-flux wellbore constants are for low-viscosity liquids; at {well.viscosity_cp:.0f} cP the tubing holdup and friction are indicative only (PHYSICS_REVIEW item R).')
        rod_check = max((r for r in (rods, rods_nogas) if r is not None), key=lambda r: r.top_stress_psi, default=None)
        if rod_check is not None and rod_check.top_stress_psi > ROD_STRESS_WARN_PSI:
            warnings.append(f'Top-rod stress {rod_check.top_stress_psi:,.0f} psi (axial load + drive torque, von Mises) on the {well.rod_od_in:g} in rod exceeds the API grade D minimum yield of {ROD_STRESS_WARN_PSI:,.0f} psi: check the rod size and grade (PHYSICS_REVIEW item S).')
        if rods_nogas is not None and rods_nogas.compressed_length_ft > 0.0:
            lift = rods_nogas.axial_load_top_lbf < 0.0
            warnings.append(f'The pump pushes the rotor up with {-rods_nogas.pump_thrust_lbf:,.0f} lbf (A_eff = A_rotor - flux < 0 for the 2:1 geometry): ' + ('it exceeds the buoyed rod weight, so the rod string would lift at the drive head. ' if lift else f'the lowest {rods_nogas.compressed_length_ft:,.0f} ft of rods are in compression. ') + 'Rod buckling is not modelled (PHYSICS_REVIEW item S).')
        if rpm > 1000.0:
            warnings.append(f"Solved RPM {rpm:.0f} is unusually high; check against the pump's rated speed (docs/PHYSICS_REVIEW.md item M).")
    return OperatingPoint(warnings=warnings, pump_model=pump.model, inlet_glr=glr_in, oil_fraction_casing_interface=t3, oil_fraction_inlet=t4, oil_fraction_casing_avg=t5, oil_fraction_wellhead=t7, oil_fraction_discharge=t8, oil_fraction_column_avg=t9, inlet_pressure_psig=p_inlet, discharge_pressure_psig=p_inlet + dp, dp_psi=dp, dp_nogas_psi=dp_nogas, inlet_gvf=gvf_in, outlet_gvf=gvf_out, gas_ratio_inlet=r_in, gas_ratio_outlet=r_out, gas_rate_std_gpm=q_gas_std, gas_rate_inlet_gpm=q_gas_in, gas_rate_discharge_gpm=q_gas_out, slip_nogas_gpm=slip_nogas, slip_final_gpm=slip_final, liquid_rate_gpm=q_gpm, rpm=rpm, rpm_nogas=rpm_nogas, torque_ftlb=torque, torque_nogas_ftlb=torque_nogas, torque_nogas_nm=torque_nogas * opts.nm_per_ftlb, torque_headline_ftlb=torque_headline, headline_is_design=opts.headline_torque == 'design', pump_torque_ftlb=pump_torque, pump_torque_nogas_ftlb=pump_torque_nogas, rod_string=rods, rod_string_nogas=rods_nogas, tubing_friction_psi=tubing.friction_psi if tubing is not None else None, tubing_friction_nogas_psi=tubing_nogas.friction_psi if tubing is not None else None, power_hp=power_hp(torque_headline, rpm), power_nogas_hp=power_nogas, ve_workbook=ve_wb, ve_simple=ve_simple, stage_pressures_psig=stage_pressures, tubing_profile=tubing.profile if tubing is not None else None, annulus_profile=annulus.profile if annulus is not None else None, polytropic_index=polytropic_index, fluid_level_ft=well.fluid_level_ft, inflow_intake_pressure_psig=inflow_target, generated_lift_m=dp_nogas * M_H2O_PER_PSI, fluid_head_psi=fluid_head, alpha_eff=coef.alpha, beta_eff=coef.beta, stages=coef.stages, gal_per_rev=coef.gal_per_rev)

def report_values(op: OperatingPoint, *, options: EngineOptions | None=None) -> dict[str, float]:
    return {'pump_differential_pressure_psi': op.dp_psi, 'generated_lift_m': op.generated_lift_m, 'flow_rate_gpm': op.liquid_rate_gpm, 'required_rpm': op.rpm, 'predicted_torque_ftlb': op.torque_headline_ftlb, 'inlet_gvf': op.inlet_gvf, 'inlet_pressure_psig': op.inlet_pressure_psig, 'power_hp': op.power_hp, 'volumetric_efficiency': op.ve_simple, 've_workbook': op.ve_workbook, 'warnings': op.warnings}
