from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, Field, field_validator
from .inflow import InflowCurve, ReservoirInflow
from .operating_point import WellInputs
from .units import SCF_PER_BBL_PER_SM3_M3, bpd_to_m3d, c_to_f, f_to_c, ft_to_m, kpa_to_psi, m3d_to_bpd, m_to_ft, pa_to_psi, psi_to_kpa, psi_to_pa
LengthUnit = Literal['m', 'ft']
PressureUnit = Literal['psig', 'kPa', 'Pa']
RateUnit = Literal['m3/d', 'bpd']
TempUnit = Literal['C', 'F']
_LENGTH_ALIASES = {'m': 'm', 'meter': 'm', 'meters': 'm', 'metre': 'm', 'metres': 'm', 'ft': 'ft', 'feet': 'ft', 'foot': 'ft'}
_PRESSURE_ALIASES = {'psig': 'psig', 'psi': 'psig', 'psia': 'psig', 'kpa': 'kPa', 'pa': 'Pa'}
_RATE_ALIASES = {'m3/d': 'm3/d', 'm3/day': 'm3/d', 'bpd': 'bpd'}
_TEMP_ALIASES = {'c': 'C', '°c': 'C', 'f': 'F', '°f': 'F'}

def _normalise(value: object, aliases: dict[str, str], kind: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f'{kind} unit must be a string, got {value!r}')
    key = value.strip().lower()
    try:
        return aliases[key]
    except KeyError:
        raise ValueError(f'Unrecognised {kind} unit {value!r}; known spellings: {sorted(set(aliases))}') from None

class WellInputsAsEntered(BaseModel):
    pump_model: str = Field(description='Inputs!I13 (B6)')
    pump_depth: float = Field(gt=0, description='Inputs!C13 (TVD)')
    pump_depth_unit: LengthUnit = 'ft'
    fluid_level: float = Field(ge=0, description='Inputs!C14, from surface')
    fluid_level_unit: LengthUnit = 'ft'
    flowline_pressure: float = Field(ge=0, description='Inputs!C15')
    flowline_pressure_unit: PressureUnit = 'psig'
    casing_pressure: float = Field(ge=0, description='Inputs!C16')
    casing_pressure_unit: PressureUnit = 'psig'
    desired_rate: float = Field(gt=0, description='Inputs!C17')
    desired_rate_unit: RateUnit = 'bpd'
    viscosity_cp: float = Field(gt=0, default=1.0, description='Inputs!C18')
    water_cut_pct: float = Field(ge=0, le=100, description='Inputs!C19')
    gor_sm3_m3: float = Field(ge=0, description="Inputs!C20; in gor_unit (the name is the workbook's unit)")
    gor_unit: Literal['sm3/m3', 'scf/bbl'] = 'sm3/m3'
    gas_through_annulus_pct: float = Field(ge=0, le=100, description='Inputs!C21')
    reservoir_temp: float = Field(description='Inputs!C22')
    reservoir_temp_unit: TempUnit = 'C'
    wellhead_temp: float = Field(description='Inputs!C23')
    wellhead_temp_unit: TempUnit = 'C'
    tubing_id_in: float = Field(default=2.441, gt=0)
    tubing_od_in: float = Field(default=2.875, gt=0)
    casing_id_in: float = Field(default=4.892, gt=0)
    rod_od_in: float = Field(default=1.0, ge=0)
    coupling_od_in: float = Field(default=2.0, ge=0)
    dogleg_severity_deg_per_100ft: float = Field(default=1.0, ge=0)
    rod_tubing_friction: float = Field(default=0.2, ge=0)
    inflow_rate: list[float] | None = None
    inflow_rate_unit: RateUnit = 'bpd'
    inflow_pressure: list[float] | None = None
    inflow_pressure_unit: PressureUnit = 'psig'
    inflow_reservoir_pressure: float | None = None
    inflow_bubble_point: float | None = None
    inflow_reservoir_pressure_unit: PressureUnit = 'psig'
    inflow_test_pressure: list[float] | None = None
    inflow_test_pressure_unit: PressureUnit = 'psig'
    inflow_test_rate: list[float] | None = None
    inflow_test_rate_unit: RateUnit = 'bpd'
    inflow_productivity_index: float | None = None
    inflow_productivity_index_unit: Literal['bpd/psi', 'm3/d/kPa'] = 'bpd/psi'
    inflow_reference_depth: float | None = None
    inflow_reference_depth_unit: LengthUnit = 'ft'
    custom_stages: float | None = None
    custom_gal_per_rev: float | None = None
    custom_alpha: float | None = None
    custom_beta: float | None = None
    custom_epsilon: float | None = None
    custom_gamma: float | None = None
    custom_length_in: float | None = None

    @field_validator('pump_depth_unit', 'fluid_level_unit', 'inflow_reference_depth_unit', mode='before')
    @classmethod
    def _norm_length(cls, v):
        return _normalise(v, _LENGTH_ALIASES, 'length') if v is not None else v

    @field_validator('flowline_pressure_unit', 'casing_pressure_unit', 'inflow_pressure_unit', 'inflow_reservoir_pressure_unit', 'inflow_test_pressure_unit', mode='before')
    @classmethod
    def _norm_pressure(cls, v):
        return _normalise(v, _PRESSURE_ALIASES, 'pressure') if v is not None else v

    @field_validator('desired_rate_unit', 'inflow_rate_unit', 'inflow_test_rate_unit', mode='before')
    @classmethod
    def _norm_rate(cls, v):
        return _normalise(v, _RATE_ALIASES, 'rate') if v is not None else v

    @field_validator('reservoir_temp_unit', 'wellhead_temp_unit', mode='before')
    @classmethod
    def _norm_temp(cls, v):
        return _normalise(v, _TEMP_ALIASES, 'temperature') if v is not None else v

    def to_well_inputs(self) -> WellInputs:
        pump_depth_ft = self.pump_depth if self.pump_depth_unit == 'ft' else m_to_ft(self.pump_depth)
        fluid_level_ft = self.fluid_level if self.fluid_level_unit == 'ft' else m_to_ft(self.fluid_level)
        flowline_pressure_psig = _pressure_to_psig(self.flowline_pressure, self.flowline_pressure_unit)
        casing_pressure_psig = _pressure_to_psig(self.casing_pressure, self.casing_pressure_unit)
        desired_rate_bpd = self.desired_rate if self.desired_rate_unit == 'bpd' else m3d_to_bpd(self.desired_rate)
        reservoir_temp_c = self.reservoir_temp if self.reservoir_temp_unit == 'C' else f_to_c(self.reservoir_temp)
        wellhead_temp_c = self.wellhead_temp if self.wellhead_temp_unit == 'C' else f_to_c(self.wellhead_temp)
        return WellInputs(pump_depth_ft=pump_depth_ft, fluid_level_ft=fluid_level_ft, flowline_pressure_psig=flowline_pressure_psig, casing_pressure_psig=casing_pressure_psig, desired_rate_bpd=desired_rate_bpd, viscosity_cp=self.viscosity_cp, water_cut_pct=self.water_cut_pct, gor_sm3_m3=self.gor_sm3_m3 if self.gor_unit == 'sm3/m3' else self.gor_sm3_m3 / SCF_PER_BBL_PER_SM3_M3, gas_through_annulus_pct=self.gas_through_annulus_pct, reservoir_temp_c=reservoir_temp_c, wellhead_temp_c=wellhead_temp_c, tubing_id_in=self.tubing_id_in, tubing_od_in=self.tubing_od_in, casing_id_in=self.casing_id_in, rod_od_in=self.rod_od_in, coupling_od_in=self.coupling_od_in, dogleg_severity_deg_per_100ft=self.dogleg_severity_deg_per_100ft, rod_tubing_friction=self.rod_tubing_friction, inflow=self._inflow())

    def _inflow(self) -> InflowCurve | None:
        ref = self.inflow_reference_depth or None
        if ref is not None and self.inflow_reference_depth_unit == 'm':
            ref = m_to_ft(ref)
        if self.inflow_rate or self.inflow_pressure:
            rates = [q if self.inflow_rate_unit == 'bpd' else m3d_to_bpd(q) for q in self.inflow_rate or []]
            pressures = [_pressure_to_psig(p, self.inflow_pressure_unit) for p in self.inflow_pressure or []]
            return InflowCurve(rate_bpd=rates, intake_pressure_psig=pressures, reference_depth_ft=ref)
        if self.inflow_reservoir_pressure is None:
            return None
        res_psig = lambda p: _pressure_to_psig(p, self.inflow_reservoir_pressure_unit)
        pi = self.inflow_productivity_index
        if pi is not None and self.inflow_productivity_index_unit == 'm3/d/kPa':
            pi = m3d_to_bpd(pi) / kpa_to_psi(1.0)
        return ReservoirInflow(reservoir_pressure_psig=res_psig(self.inflow_reservoir_pressure), bubble_point_psig=res_psig(self.inflow_bubble_point) if self.inflow_bubble_point else None, test_pressure_psig=[_pressure_to_psig(p, self.inflow_test_pressure_unit) for p in self.inflow_test_pressure or []], test_rate_bpd=[q if self.inflow_test_rate_unit == 'bpd' else m3d_to_bpd(q) for q in self.inflow_test_rate or []], productivity_index_bpd_psi=pi, reference_depth_ft=ref).to_curve()

    @classmethod
    def from_well_inputs(cls, well: WellInputs, *, pump_model: str, pump_depth_unit: LengthUnit='ft', fluid_level_unit: LengthUnit='ft', flowline_pressure_unit: PressureUnit='psig', casing_pressure_unit: PressureUnit='psig', desired_rate_unit: RateUnit='bpd', gor_unit: Literal['sm3/m3', 'scf/bbl']='sm3/m3', reservoir_temp_unit: TempUnit='C', wellhead_temp_unit: TempUnit='C', **custom_pump_fields) -> 'WellInputsAsEntered':
        pump_depth = well.pump_depth_ft if pump_depth_unit == 'ft' else ft_to_m(well.pump_depth_ft)
        fluid_level = well.fluid_level_ft if fluid_level_unit == 'ft' else ft_to_m(well.fluid_level_ft)
        flowline_pressure = _psig_to_pressure(well.flowline_pressure_psig, flowline_pressure_unit)
        casing_pressure = _psig_to_pressure(well.casing_pressure_psig, casing_pressure_unit)
        desired_rate = well.desired_rate_bpd if desired_rate_unit == 'bpd' else bpd_to_m3d(well.desired_rate_bpd)
        reservoir_temp = well.reservoir_temp_c if reservoir_temp_unit == 'C' else c_to_f(well.reservoir_temp_c)
        wellhead_temp = well.wellhead_temp_c if wellhead_temp_unit == 'C' else c_to_f(well.wellhead_temp_c)
        return cls(pump_model=pump_model, pump_depth=pump_depth, pump_depth_unit=pump_depth_unit, fluid_level=fluid_level, fluid_level_unit=fluid_level_unit, flowline_pressure=flowline_pressure, flowline_pressure_unit=flowline_pressure_unit, casing_pressure=casing_pressure, casing_pressure_unit=casing_pressure_unit, desired_rate=desired_rate, desired_rate_unit=desired_rate_unit, viscosity_cp=well.viscosity_cp, water_cut_pct=well.water_cut_pct, gor_sm3_m3=well.gor_sm3_m3 if gor_unit == 'sm3/m3' else well.gor_sm3_m3 * SCF_PER_BBL_PER_SM3_M3, gor_unit=gor_unit, gas_through_annulus_pct=well.gas_through_annulus_pct, reservoir_temp=reservoir_temp, reservoir_temp_unit=reservoir_temp_unit, wellhead_temp=wellhead_temp, wellhead_temp_unit=wellhead_temp_unit, tubing_id_in=well.tubing_id_in, tubing_od_in=well.tubing_od_in, casing_id_in=well.casing_id_in, rod_od_in=well.rod_od_in, coupling_od_in=well.coupling_od_in, dogleg_severity_deg_per_100ft=well.dogleg_severity_deg_per_100ft, rod_tubing_friction=well.rod_tubing_friction, inflow_rate=list(well.inflow.rate_bpd) if well.inflow else None, inflow_pressure=list(well.inflow.intake_pressure_psig) if well.inflow else None, inflow_reference_depth=well.inflow.reference_depth_ft if well.inflow else None, **custom_pump_fields)

def _pressure_to_psig(value: float, unit: PressureUnit) -> float:
    if unit == 'psig':
        return value
    if unit == 'kPa':
        return kpa_to_psi(value)
    if unit == 'Pa':
        return pa_to_psi(value)
    raise ValueError(f'Unhandled pressure unit {unit!r}')

def _psig_to_pressure(value_psig: float, unit: PressureUnit) -> float:
    if unit == 'psig':
        return value_psig
    if unit == 'kPa':
        return psi_to_kpa(value_psig)
    if unit == 'Pa':
        return psi_to_pa(value_psig)
    raise ValueError(f'Unhandled pressure unit {unit!r}')
