from __future__ import annotations
import math
from pydantic import BaseModel
from scipy.optimize import brentq
import numpy as np
from . import fluids, staged_gas
from .catalog import PumpSpec
from .operating_point import OperatingPoint, WellInputs, solve_operating_point
from .options import EngineOptions
from .pump_model import PumpCoefficients
from .units import BPD_PER_GPM, BPD_PER_M3D_SWEEP, FT_PER_M, HP_PER_KW, KW_PER_HP, M3D_PER_GPM, M_H2O_PER_PSI, M_PER_FT, GPM_PER_BPD, NM_PER_FTLB, PSI_PER_FT_WATER, PSI_PER_M_H2O, bpd_to_m3d
DEFAULT_SWEEP_RPMS = (100.0, 200.0, 300.0, 400.0)

class LiftSweepRow(BaseModel):
    lift_m: float
    lift_ft: float
    dp_psi: float
    dp_per_stage_psi: float
    slip_gpm: float
    flow_gpm: dict[float, float]
    flow_m3d: dict[float, float]
    flow_bpd: dict[float, float]
    torque_ftlb: float
    torque_nm: float
    power_in_kw: dict[float, float]
    power_in_hp: dict[float, float]
    power_out_kw: dict[float, float]
    efficiency: dict[float, float]

class RpmSweepRow(BaseModel):
    rpm: float
    flow_gpm: float
    flow_m3d: float
    flow_bpd: float

def lift_sweep(coef: PumpCoefficients, *, rpms: tuple[float, ...]=DEFAULT_SWEEP_RPMS, lift_step_m: float=5.0, n_rows: int=481, options: EngineOptions | None=None) -> list[LiftSweepRow]:
    opts = (options or EngineOptions.parity()).resolved()
    rows = []
    for i in range(n_rows):
        lift_m = 1e-09 if i == 0 else i * lift_step_m
        dp = lift_m * PSI_PER_M_H2O
        dp_stage = dp / coef.stages
        slip = coef.alpha * (dp / coef.stages) ** coef.beta
        torque = coef.torque(dp)
        torque_nm = torque * NM_PER_FTLB
        flow_gpm = {r: coef.gal_per_rev * r - slip for r in rpms}
        power_in_kw = {r: torque_nm * r / 9.5488 / 1000.0 for r in rpms}
        power_out_kw = {r: KW_PER_HP * flow_gpm[r] * dp / opts.hydraulic_power_divisor for r in rpms}
        rows.append(LiftSweepRow(lift_m=lift_m, lift_ft=lift_m * FT_PER_M, dp_psi=dp, dp_per_stage_psi=dp_stage, slip_gpm=slip, flow_gpm=flow_gpm, flow_m3d={r: v * M3D_PER_GPM for r, v in flow_gpm.items()}, flow_bpd={r: v * BPD_PER_GPM for r, v in flow_gpm.items()}, torque_ftlb=torque, torque_nm=torque_nm, power_in_kw=power_in_kw, power_in_hp={r: v * HP_PER_KW for r, v in power_in_kw.items()}, power_out_kw=power_out_kw, efficiency={r: power_out_kw[r] / power_in_kw[r] if power_in_kw[r] else float('nan') for r in rpms}))
    return rows

def rpm_sweep(coef: PumpCoefficients, op: OperatingPoint, *, rpm_step: float=2.0, n_rows: int=481, options: EngineOptions | None=None) -> list[RpmSweepRow]:
    opts = (options or EngineOptions.parity()).resolved()
    glr = op.inlet_glr
    r_in = op.gas_ratio_inlet
    r_out = op.gas_ratio_outlet
    staged_flow = _staged_flow_vs_rpm(coef, op, opts.staged_gas_leak) if opts.slip_gas_model == 'staged' else None
    rows = []
    for i in range(n_rows):
        rpm = i * rpm_step
        displaced = coef.gal_per_rev * rpm
        if staged_flow is not None:
            flow = staged_flow(rpm)
        else:
            flow = min((displaced - op.slip_nogas_gpm) / (1 + r_out * glr), displaced / (1 + r_in * glr))
        if opts.clamp_curve_flow_at_zero:
            flow = max(flow, 0.0)
        m3d = flow * M3D_PER_GPM
        rows.append(RpmSweepRow(rpm=rpm, flow_gpm=flow, flow_m3d=m3d, flow_bpd=m3d * BPD_PER_M3D_SWEEP))
    return rows

def _staged_flow_vs_rpm(coef: PumpCoefficients, op: OperatingPoint, gas_leak: float=0.0, n_grid: int=200):
    x = op.gas_ratio_inlet * op.inlet_glr
    ql_max = max(4.0 * op.liquid_rate_gpm, 1.0)
    ql = np.linspace(0.0, ql_max, n_grid)
    losses, _ = staged_gas.loss_many(ql * x, op.inlet_pressure_psig, op.dp_psi, coef.alpha, coef.beta, coef.stages, op.polytropic_index, liquid_gpm=ql, gas_leak=gas_leak)
    k0 = float(losses[0])
    rpm_grid = (ql + losses) / coef.gal_per_rev
    rpm0 = k0 / coef.gal_per_rev

    def flow(rpm: float) -> float:
        if rpm <= rpm0:
            return coef.gal_per_rev * rpm - k0
        if rpm >= rpm_grid[-1]:
            slope = (ql[-1] - ql[-2]) / (rpm_grid[-1] - rpm_grid[-2])
            return float(ql[-1] + slope * (rpm - rpm_grid[-1]))
        return float(np.interp(rpm, rpm_grid, ql))
    return flow

class PumpCurveBasis(BaseModel):
    inlet_pressure_psig: float
    inlet_gvf: float
    temperature_c: float
    mode: str
    operating_rpm: float | None = None

class PumpCurve(BaseModel):
    basis: PumpCurveBasis
    dp_psi: list[float]
    head_m_h2o: list[float]
    torque_ftlb: list[float]
    torque_nm: list[float]
    flow_gpm: dict[float, list[float]]
    flow_bpd: dict[float, list[float]]
    flow_m3d: dict[float, list[float]]
    power_in_hp: dict[float, list[float]]
    power_in_kw: dict[float, list[float]]
    power_hydraulic_kw: dict[float, list[float]]
    efficiency: dict[float, list[float]]

def pump_curve(well: WellInputs, coef: PumpCoefficients, op: OperatingPoint, options: EngineOptions | None=None, *, dp_max_psi: float | None=None, n: int=60, rpms: tuple[float, ...]=DEFAULT_SWEEP_RPMS, include_operating_rpm: bool=False) -> PumpCurve:
    opts = (options or EngineOptions.parity()).resolved()
    poly_n = opts.polytropic_index_override if opts.polytropic_index_override is not None else well.polytropic_index
    p_inlet = op.inlet_pressure_psig
    r_in = op.gas_ratio_inlet
    glr_in = op.inlet_glr
    q_gas_in = op.gas_rate_inlet_gpm
    denom = 1.0 + r_in * glr_in
    if include_operating_rpm and op.rpm not in rpms:
        rpms = (*rpms, op.rpm)
    dp_max = dp_max_psi if dp_max_psi is not None else max(1.5 * op.dp_psi, op.dp_psi)
    n = max(n, 2)
    dp_values = [dp_max * i / (n - 1) for i in range(n)]
    torque_ftlb: list[float] = []
    torque_nm: list[float] = []
    slip_eff_values: list[float] = []
    for dp in dp_values:
        slip_nogas = coef.slip(dp)
        if opts.slip_gas_model == 'netting':
            q_gas_out = q_gas_in * fluids.polytropic_volume_ratio(p_inlet, dp, poly_n)
            slip_eff = max(slip_nogas - (q_gas_in - q_gas_out), 0.0)
        else:
            slip_eff = slip_nogas
        slip_eff_values.append(slip_eff)
        t = coef.torque(dp)
        torque_ftlb.append(t)
        torque_nm.append(t * NM_PER_FTLB)
    flow_gpm: dict[float, list[float]] = {}
    flow_bpd: dict[float, list[float]] = {}
    flow_m3d: dict[float, list[float]] = {}
    power_in_kw: dict[float, list[float]] = {}
    power_in_hp: dict[float, list[float]] = {}
    power_hydraulic_kw: dict[float, list[float]] = {}
    efficiency: dict[float, list[float]] = {}
    staged_flows = None
    if opts.slip_gas_model == 'staged':
        grid_qd = np.array([[coef.gal_per_rev * r] * n for r in rpms])
        grid_dp = np.array([dp_values] * len(rpms))
        staged_flows = staged_gas.liquid_rate_at_speed_many(grid_qd, r_in * glr_in, p_inlet, grid_dp, coef.alpha, coef.beta, coef.stages, poly_n, gas_leak=opts.staged_gas_leak).reshape(len(rpms), n)
    for j, r in enumerate(rpms):
        if staged_flows is not None:
            q_r = [float(v) for v in staged_flows[j]]
        else:
            q_r = [(coef.gal_per_rev * r - slip_eff_values[i]) / denom for i in range(n)]
        flow_gpm[r] = q_r
        flow_bpd[r] = [v * BPD_PER_GPM for v in q_r]
        flow_m3d[r] = [v * M3D_PER_GPM for v in q_r]
        pin_kw = [torque_nm[i] * r / 9.5488 / 1000.0 for i in range(n)]
        power_in_kw[r] = pin_kw
        power_in_hp[r] = [v * HP_PER_KW for v in pin_kw]
        phyd = [KW_PER_HP * q_r[i] * dp_values[i] / opts.hydraulic_power_divisor for i in range(n)]
        power_hydraulic_kw[r] = phyd
        efficiency[r] = [phyd[i] / pin_kw[i] if pin_kw[i] else float('nan') for i in range(n)]
    basis = PumpCurveBasis(inlet_pressure_psig=p_inlet, inlet_gvf=op.inlet_gvf, temperature_c=well.reservoir_temp_c, mode=opts.mode, operating_rpm=op.rpm if include_operating_rpm else None)
    return PumpCurve(basis=basis, dp_psi=dp_values, head_m_h2o=[dp * M_H2O_PER_PSI for dp in dp_values], torque_ftlb=torque_ftlb, torque_nm=torque_nm, flow_gpm=flow_gpm, flow_bpd=flow_bpd, flow_m3d=flow_m3d, power_in_hp=power_in_hp, power_in_kw=power_in_kw, power_hydraulic_kw=power_hydraulic_kw, efficiency=efficiency)
DELIVERABLE_RATE_XTOL_BPD = 0.0001

def _rpm_at_rate(well: WellInputs, pump: PumpSpec, alpha: float, options: EngineOptions | None, rate_bpd: float) -> float:
    w = well.model_copy(update={'desired_rate_bpd': rate_bpd})
    op = solve_operating_point(w, pump, alpha_override=alpha, options=options)
    return op.rpm

def _deliverable_rate_bpd(well: WellInputs, pump: PumpSpec, alpha: float, options: EngineOptions | None, rpm_target: float, warnings: list[str], guess_bpd: float | None=None) -> float:

    def f(rate_bpd: float) -> float:
        try:
            return _rpm_at_rate(well, pump, alpha, options, rate_bpd) - rpm_target
        except (ValueError, ZeroDivisionError, OverflowError):
            return float('nan')
    if guess_bpd is not None and math.isfinite(guess_bpd) and (guess_bpd > 0.001):
        lo, hi = (guess_bpd / 1.1, guess_bpd * 1.1)
        flo, fhi = (f(lo), f(hi))
        for _ in range(8):
            if math.isnan(flo) or math.isnan(fhi) or flo < 0.0 < fhi:
                break
            if flo >= 0.0:
                hi, fhi = (lo, flo)
                lo = max(lo / 1.5, 0.001)
                flo = f(lo)
            else:
                lo, flo = (hi, fhi)
                hi *= 1.5
                fhi = f(hi)
        if not (math.isnan(flo) or math.isnan(fhi)) and flo * fhi <= 0.0:
            return brentq(f, lo, hi, xtol=DELIVERABLE_RATE_XTOL_BPD)
    lo = 0.001
    hi = max(well.desired_rate_bpd * 20.0, 10.0)
    flo, fhi = (f(lo), f(hi))
    tries = 0
    while (math.isnan(flo) or math.isnan(fhi) or flo * fhi > 0) and tries < 6:
        hi *= 2.0
        fhi = f(hi)
        tries += 1
    if math.isnan(flo) or math.isnan(fhi) or flo * fhi > 0:
        msg = 'drawdown/setting-depth: no root found for the fixed-RPM deliverable rate at some levels.'
        if msg not in warnings:
            warnings.append(msg)
        return float('nan')
    return brentq(f, lo, hi, xtol=DELIVERABLE_RATE_XTOL_BPD)

class DrawdownBasis(BaseModel):
    pump_depth_ft: float
    desired_rate_bpd: float
    rpm_fixed: float
    mode: str

class DrawdownCurve(BaseModel):
    basis: DrawdownBasis
    fluid_level_ft: list[float]
    fluid_level_m: list[float]
    required_rpm: list[float]
    torque_ftlb: list[float]
    torque_nm: list[float]
    power_hp: list[float]
    power_kw: list[float]
    inlet_pressure_psig: list[float]
    inlet_gvf: list[float]
    dp_psi: list[float]
    fixed_rpm_rate_bpd: list[float]
    fixed_rpm_rate_m3d: list[float]
    warnings: list[str]

def drawdown_curve(well: WellInputs, coef: PumpCoefficients, options: EngineOptions | None=None, *, n: int=40, rpm_fixed: float | None=None) -> DrawdownCurve:
    pump = coef.pump
    alpha = coef.alpha
    warnings: list[str] = []
    if rpm_fixed is None:
        op0 = solve_operating_point(well, pump, alpha_override=alpha, options=options)
        rpm_fixed = op0.rpm
    n = max(n, 2)
    levels = [well.pump_depth_ft * i / (n - 1) for i in range(n)]
    required_rpm: list[float] = []
    torque_ftlb: list[float] = []
    torque_nm: list[float] = []
    power_hp: list[float] = []
    power_kw: list[float] = []
    inlet_pressure_psig: list[float] = []
    inlet_gvf: list[float] = []
    dp_psi: list[float] = []
    fixed_rpm_rate_bpd: list[float] = []
    fixed_rpm_rate_m3d: list[float] = []
    last_rate: float | None = None
    for level in levels:
        w = well.model_copy(update={'fluid_level_ft': level})
        try:
            op = solve_operating_point(w, pump, alpha_override=alpha, options=options)
            required_rpm.append(op.rpm)
            torque_ftlb.append(op.torque_ftlb)
            torque_nm.append(op.torque_ftlb * NM_PER_FTLB)
            power_hp.append(op.power_hp)
            power_kw.append(op.power_hp * KW_PER_HP)
            inlet_pressure_psig.append(op.inlet_pressure_psig)
            inlet_gvf.append(op.inlet_gvf)
            dp_psi.append(op.dp_psi)
        except (ValueError, ZeroDivisionError, OverflowError) as exc:
            msg = f'drawdown_curve: solve failed at a fluid level ({exc}).'
            if msg not in warnings:
                warnings.append(msg)
            required_rpm.append(float('nan'))
            torque_ftlb.append(float('nan'))
            torque_nm.append(float('nan'))
            power_hp.append(float('nan'))
            power_kw.append(float('nan'))
            inlet_pressure_psig.append(float('nan'))
            inlet_gvf.append(float('nan'))
            dp_psi.append(float('nan'))
        rate = _deliverable_rate_bpd(w, pump, alpha, options, rpm_fixed, warnings, guess_bpd=last_rate)
        last_rate = rate if math.isfinite(rate) else last_rate
        fixed_rpm_rate_bpd.append(rate)
        fixed_rpm_rate_m3d.append(rate / BPD_PER_M3D_SWEEP if not math.isnan(rate) else float('nan'))
    basis = DrawdownBasis(pump_depth_ft=well.pump_depth_ft, desired_rate_bpd=well.desired_rate_bpd, rpm_fixed=rpm_fixed, mode=(options or EngineOptions.parity()).resolved().mode)
    return DrawdownCurve(basis=basis, fluid_level_ft=levels, fluid_level_m=[level * M_PER_FT for level in levels], required_rpm=required_rpm, torque_ftlb=torque_ftlb, torque_nm=torque_nm, power_hp=power_hp, power_kw=power_kw, inlet_pressure_psig=inlet_pressure_psig, inlet_gvf=inlet_gvf, dp_psi=dp_psi, fixed_rpm_rate_bpd=fixed_rpm_rate_bpd, fixed_rpm_rate_m3d=fixed_rpm_rate_m3d, warnings=warnings)

class SettingDepthBasis(BaseModel):
    fluid_level_ft: float
    desired_rate_bpd: float
    rpm_fixed: float
    mode: str

class SettingDepthCurve(BaseModel):
    basis: SettingDepthBasis
    pump_depth_ft: list[float]
    pump_depth_m: list[float]
    required_rpm: list[float]
    torque_ftlb: list[float]
    torque_nm: list[float]
    power_hp: list[float]
    power_kw: list[float]
    inlet_pressure_psig: list[float]
    inlet_gvf: list[float]
    dp_psi: list[float]
    fixed_rpm_rate_bpd: list[float]
    fixed_rpm_rate_m3d: list[float]
    warnings: list[str]

def setting_depth_sweep(well: WellInputs, coef: PumpCoefficients, options: EngineOptions | None=None, *, depths_ft: list[float], rpm_fixed: float | None=None) -> SettingDepthCurve:
    pump = coef.pump
    alpha = coef.alpha
    warnings: list[str] = []
    if rpm_fixed is None:
        op0 = solve_operating_point(well, pump, alpha_override=alpha, options=options)
        rpm_fixed = op0.rpm
    required_rpm: list[float] = []
    torque_ftlb: list[float] = []
    torque_nm: list[float] = []
    power_hp: list[float] = []
    power_kw: list[float] = []
    inlet_pressure_psig: list[float] = []
    inlet_gvf: list[float] = []
    dp_psi: list[float] = []
    fixed_rpm_rate_bpd: list[float] = []
    fixed_rpm_rate_m3d: list[float] = []
    last_rate: float | None = None
    for depth in depths_ft:
        w = well.model_copy(update={'pump_depth_ft': depth})
        try:
            op = solve_operating_point(w, pump, alpha_override=alpha, options=options)
            required_rpm.append(op.rpm)
            torque_ftlb.append(op.torque_ftlb)
            torque_nm.append(op.torque_ftlb * NM_PER_FTLB)
            power_hp.append(op.power_hp)
            power_kw.append(op.power_hp * KW_PER_HP)
            inlet_pressure_psig.append(op.inlet_pressure_psig)
            inlet_gvf.append(op.inlet_gvf)
            dp_psi.append(op.dp_psi)
        except (ValueError, ZeroDivisionError, OverflowError) as exc:
            msg = f'setting_depth_sweep: solve failed at a pump depth ({exc}).'
            if msg not in warnings:
                warnings.append(msg)
            required_rpm.append(float('nan'))
            torque_ftlb.append(float('nan'))
            torque_nm.append(float('nan'))
            power_hp.append(float('nan'))
            power_kw.append(float('nan'))
            inlet_pressure_psig.append(float('nan'))
            inlet_gvf.append(float('nan'))
            dp_psi.append(float('nan'))
        rate = _deliverable_rate_bpd(w, pump, alpha, options, rpm_fixed, warnings, guess_bpd=last_rate)
        last_rate = rate if math.isfinite(rate) else last_rate
        fixed_rpm_rate_bpd.append(rate)
        fixed_rpm_rate_m3d.append(rate / BPD_PER_M3D_SWEEP if not math.isnan(rate) else float('nan'))
    basis = SettingDepthBasis(fluid_level_ft=well.fluid_level_ft, desired_rate_bpd=well.desired_rate_bpd, rpm_fixed=rpm_fixed, mode=(options or EngineOptions.parity()).resolved().mode)
    return SettingDepthCurve(basis=basis, pump_depth_ft=list(depths_ft), pump_depth_m=[d * M_PER_FT for d in depths_ft], required_rpm=required_rpm, torque_ftlb=torque_ftlb, torque_nm=torque_nm, power_hp=power_hp, power_kw=power_kw, inlet_pressure_psig=inlet_pressure_psig, inlet_gvf=inlet_gvf, dp_psi=dp_psi, fixed_rpm_rate_bpd=fixed_rpm_rate_bpd, fixed_rpm_rate_m3d=fixed_rpm_rate_m3d, warnings=warnings)

class InflowRpmCurve(BaseModel):
    rpm: list[float]
    liquid_bpd: list[float]
    gas_inlet_bpd: list[float]
    slip_bpd: list[float]
    displacement_bpd: list[float]
    liquid_m3d: list[float]
    gas_inlet_m3d: list[float]
    slip_m3d: list[float]
    displacement_m3d: list[float]
    intake_pressure_psig: list[float]
    fluid_level_ft: list[float]
    inlet_gvf: list[float]
    torque_ftlb: list[float]
    power_hp: list[float]
    pump_off_rate_bpd: float
    warnings: list[str]

def inflow_rpm_curve(well: WellInputs, coef: PumpCoefficients, options: EngineOptions | None=None, *, n: int=40) -> InflowRpmCurve:
    from .operating_point import _intake_pressure
    if well.inflow is None:
        raise ValueError('inflow_rpm_curve needs well.inflow')
    opts = (options or EngineOptions.parity()).resolved()
    gradient = opts.liquid_gradient_psi_per_ft if opts.liquid_gradient_psi_per_ft is not None else PSI_PER_FT_WATER
    glr_in = fluids.inlet_gas_liquid_ratio(well.gor_sm3_m3, well.water_cut_pct, well.gas_through_annulus_pct)
    warnings: list[str] = []
    well = well.model_copy(update={'inflow': well.inflow.at_pump(well.pump_depth_ft, gradient)})

    def excess(q_bpd: float) -> float:
        w = well.model_copy(update={'fluid_level_ft': well.pump_depth_ft, 'desired_rate_bpd': q_bpd})
        return well.inflow.pressure_psig(q_bpd) - _intake_pressure(w, opts, gradient, glr_in, q_bpd * GPM_PER_BPD)
    q_lo = 0.001
    q_hi = well.inflow.max_rate_bpd
    if not math.isfinite(q_hi):
        q_hi = 10.0 * well.inflow.rate_bpd[-1]
    if excess(q_lo) <= 0.0:
        warnings.append("The inflow curve's intake pressure is below the pumped-off intake pressure (casing pressure plus the gas column) at every rate, so there is no operating range to plot.")
        q_off = float('nan')
        rates: list[float] = []
    else:
        q_off = brentq(excess, q_lo, q_hi, xtol=1e-06) if excess(q_hi) < 0.0 else q_hi
        n = max(n, 2)
        rates = [q_off * 1e-09] + [q_off * i / n for i in range(1, n + 1)]
    out: dict[str, list[float]] = {k: [] for k in ('rpm', 'liquid_bpd', 'gas_inlet_bpd', 'slip_bpd', 'displacement_bpd', 'intake_pressure_psig', 'fluid_level_ft', 'inlet_gvf', 'torque_ftlb', 'power_hp')}
    for q in rates:
        w = well.model_copy(update={'desired_rate_bpd': q})
        try:
            op = solve_operating_point(w, coef.pump, alpha_override=coef.alpha, options=options)
        except (ValueError, ZeroDivisionError, OverflowError) as exc:
            msg = f'inflow_rpm_curve: solve failed at a rate ({exc}).'
            if msg not in warnings:
                warnings.append(msg)
            continue
        out['rpm'].append(op.rpm)
        out['liquid_bpd'].append(q)
        out['gas_inlet_bpd'].append(op.gas_rate_inlet_gpm * BPD_PER_GPM)
        out['slip_bpd'].append(op.slip_final_gpm * BPD_PER_GPM)
        out['displacement_bpd'].append(op.rpm * op.gal_per_rev * BPD_PER_GPM)
        out['intake_pressure_psig'].append(op.inlet_pressure_psig)
        out['fluid_level_ft'].append(op.fluid_level_ft)
        out['inlet_gvf'].append(op.inlet_gvf)
        out['torque_ftlb'].append(op.torque_ftlb)
        out['power_hp'].append(op.power_hp)
    if out['rpm']:
        for k in ('rpm', 'liquid_bpd', 'gas_inlet_bpd', 'slip_bpd', 'displacement_bpd', 'power_hp'):
            out[k].insert(0, 0.0)
        for k in ('intake_pressure_psig', 'fluid_level_ft', 'inlet_gvf', 'torque_ftlb'):
            out[k].insert(0, out[k][0])
    m3d = {f'{k[:-4]}_m3d': [bpd_to_m3d(v) for v in out[k]] for k in ('liquid_bpd', 'gas_inlet_bpd', 'slip_bpd', 'displacement_bpd')}
    return InflowRpmCurve(**out, **m3d, pump_off_rate_bpd=q_off, warnings=warnings)
