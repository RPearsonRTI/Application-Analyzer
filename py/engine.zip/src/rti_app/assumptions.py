from __future__ import annotations
from typing import Literal
from pydantic import BaseModel
from . import estimates as est
from .inputs import WellInputsAsEntered
from .units import M_PER_FT
GEOTHERMAL_C_PER_M = 0.03
DEFAULT_API_FOR_DENSITY = 15.0
COUPLING_FULL = {0.625: 1.5, 0.75: 1.625, 0.875: 1.8125, 1.0: 2.1875, 1.125: 2.375}
COUPLING_SLIM = {0.625: 1.25, 0.75: 1.5, 0.875: 1.625, 1.0: 2.0}
MIN_COUPLING_CLEARANCE_IN = 0.4
FIELDS: dict[str, tuple[str, str]] = {'pump_depth': ('Pump depth (TVD)', 'pump_depth_unit'), 'fluid_level': ('Fluid level from surface', 'fluid_level_unit'), 'flowline_pressure': ('Flowline pressure', 'flowline_pressure_unit'), 'casing_pressure': ('Casing pressure', 'casing_pressure_unit'), 'desired_rate': ('Desired rate', 'desired_rate_unit'), 'water_cut_pct': ('Water cut', '%'), 'gor_sm3_m3': ('GOR', 'gor_unit'), 'reservoir_temp': ('Reservoir temperature', 'reservoir_temp_unit'), 'viscosity_cp': ('Viscosity', 'cP'), 'wellhead_temp': ('Wellhead temperature', 'wellhead_temp_unit'), 'gas_through_annulus_pct': ('Gas through annulus', '%'), 'tubing_id_in': ('Tubing ID', 'in'), 'tubing_od_in': ('Tubing OD', 'in'), 'casing_id_in': ('Casing ID', 'in'), 'rod_od_in': ('Rod diameter', 'in'), 'coupling_od_in': ('Rod coupling OD', 'in'), 'dogleg_severity_deg_per_100ft': ('Dogleg severity', 'deg/100 ft'), 'rod_tubing_friction': ('Rod-tubing friction coefficient', '')}
REQUIRED = ('pump_depth', 'desired_rate', 'flowline_pressure', 'water_cut_pct', 'gor_sm3_m3')
UNIT_DEFAULTS = {name: field.default for name, field in WellInputsAsEntered.model_fields.items() if name.endswith('_unit')}

class InputSource(BaseModel):
    field: str
    label: str
    value: float
    unit: str
    source: Literal['given', 'estimated', 'assumed']
    basis: str = ''

class Resolved(BaseModel):
    well: dict
    inputs: list[InputSource]
    notes: list[str] = []

def _blank(v) -> bool:
    return v is None or v == '' or (isinstance(v, list) and (not v))

def _from_c(temp_c: float, unit: str) -> float:
    return temp_c if str(unit).upper().endswith('C') else temp_c * 9.0 / 5.0 + 32.0

def resolve(raw_well: dict, oil_api_gravity: float | None=None, surface_earth_temp_c: float=10.0) -> Resolved:
    well = {k: v for k, v in raw_well.items() if not _blank(v)}
    filled: dict[str, tuple[str, str]] = {}
    notes: list[str] = []

    def fill(field: str, value: float, source: str, basis: str) -> None:
        well[field] = value
        filled[field] = (source, basis)
    has_inflow = 'inflow_rate' in well or 'inflow_reservoir_pressure' in well
    missing = [FIELDS[f][0] for f in REQUIRED if f not in well]
    if 'pump_model' not in well:
        missing.insert(0, 'Pump model')
    if 'fluid_level' not in well and (not has_inflow):
        missing.append('Fluid level from surface (or well inflow data)')
    if missing:
        raise ValueError('These inputs cannot be assumed; please enter them: ' + ', '.join(missing) + '.')
    unit = lambda name: well.get(name, UNIT_DEFAULTS[name])
    if 'fluid_level' not in well:
        well['fluid_level'] = well['pump_depth']
        well['fluid_level_unit'] = unit('pump_depth_unit')
        notes.append('Fluid level: not entered; it is back-solved from the well inflow data.')
    if 'casing_pressure' not in well:
        well['casing_pressure_unit'] = unit('flowline_pressure_unit')
        fill('casing_pressure', well['flowline_pressure'], 'assumed', 'Set equal to the flowline pressure: casing gas assumed tied into the flowline.')
    depth_m = well['pump_depth'] * (M_PER_FT if str(unit('pump_depth_unit')).lower().startswith('f') else 1.0)
    if 'reservoir_temp' not in well:
        t = surface_earth_temp_c + GEOTHERMAL_C_PER_M * depth_m
        fill('reservoir_temp', round(_from_c(t, unit('reservoir_temp_unit')), 1), 'assumed', f'Geothermal gradient of {GEOTHERMAL_C_PER_M * 1000:.0f} degC/km from a surface earth temperature of {surface_earth_temp_c:g} degC over {depth_m:,.0f} m. Not valid for thermal (steam) wells.')
    if 'tubing_id_in' not in well and 'tubing_od_in' not in well:
        fill('tubing_od_in', 2.875, 'assumed', '2-7/8 in 6.5 lb/ft tubing, as on Rotoliptic installs to date.')
        fill('tubing_id_in', 2.441, 'assumed', '2-7/8 in 6.5 lb/ft tubing, as on Rotoliptic installs to date.')
    elif 'tubing_od_in' not in well:
        fill('tubing_od_in', round(well['tubing_id_in'] + 0.434, 3), 'assumed', 'Tubing wall of 0.217 in (as 2-7/8 in 6.5 lb/ft) added to the entered ID.')
    elif 'tubing_id_in' not in well:
        fill('tubing_id_in', round(well['tubing_od_in'] - 0.434, 3), 'assumed', 'Tubing wall of 0.217 in (as 2-7/8 in 6.5 lb/ft) taken off the entered OD.')
    if 'casing_id_in' not in well:
        fill('casing_id_in', 4.892, 'assumed', '5-1/2 in 17 lb/ft casing, as on Rotoliptic installs to date.')
    if 'rod_od_in' not in well:
        r65 = str(well['pump_model']).upper().startswith('R65')
        fill('rod_od_in', 0.875 if r65 else 1.0, 'assumed', f"Grade D sucker rod, {('7/8 in for R65 pumps' if r65 else '1 in for R200 and larger pumps')}.")
    if 'coupling_od_in' not in well:
        rod = float(well['rod_od_in'])
        full, slim = (COUPLING_FULL.get(rod), COUPLING_SLIM.get(rod))
        if rod <= 0:
            fill('coupling_od_in', 0.0, 'assumed', 'Rodless: no couplings.')
        elif full is None:
            fill('coupling_od_in', rod, 'assumed', f'No API coupling size for a {rod:g} in rod: continuous rod assumed.')
        elif well['tubing_id_in'] - full >= MIN_COUPLING_CLEARANCE_IN or slim is None:
            gap = well['tubing_id_in'] - full
            tight = '' if gap >= MIN_COUPLING_CLEARANCE_IN else f" Only {gap:.2f} in is left inside the {well['tubing_id_in']:g} in tubing and there is no slim-hole size: check the rod and tubing sizes."
            fill('coupling_od_in', full, 'assumed', f'API full-size coupling for a {rod:g} in rod.' + tight)
        else:
            fill('coupling_od_in', slim, 'assumed', f"API slim-hole coupling for a {rod:g} in rod: the full-size {full:g} in coupling would leave under {MIN_COUPLING_CLEARANCE_IN:g} in inside the {well['tubing_id_in']:g} in tubing.")
    if 'dogleg_severity_deg_per_100ft' not in well:
        fill('dogleg_severity_deg_per_100ft', 1.0, 'assumed', 'No directional survey: a near-vertical well with a uniform tortuosity of 1 deg/100 ft.')
    if 'rod_tubing_friction' not in well:
        fill('rod_tubing_friction', 0.2, 'assumed', 'Steel couplings on steel tubing in produced fluid; typical 0.2.')
    todo = [f for f in ('viscosity_cp', 'wellhead_temp', 'gas_through_annulus_pct') if f not in well]
    if todo:
        probe = {**well}
        probe.setdefault('viscosity_cp', 1.0)
        probe.setdefault('gas_through_annulus_pct', 50.0)
        if 'wellhead_temp' not in probe:
            probe['wellhead_temp'], probe['wellhead_temp_unit'] = (well['reservoir_temp'], unit('reservoir_temp_unit'))
        w = WellInputsAsEntered(**probe).to_well_inputs()
        wc = w.water_cut_pct / 100.0
        api = oil_api_gravity if oil_api_gravity else DEFAULT_API_FOR_DENSITY
        density_note = '' if oil_api_gravity else f' Oil density taken as API {DEFAULT_API_FOR_DENSITY:g} (no API gravity entered).'
        if 'viscosity_cp' in todo:
            mu_w = est.water_viscosity_cp(w.reservoir_temp_c)
            if oil_api_gravity:
                mu_o = est.dead_oil_viscosity_cp(oil_api_gravity, w.reservoir_temp_c)
                mu, phase = est.mixture_viscosity_cp(mu_o, mu_w, wc)
                basis = f'Dead oil {mu_o:.3g} cP (Beggs-Robinson, API {oil_api_gravity:g} at {w.reservoir_temp_c:.0f} degC), water {mu_w:.2f} cP; {phase}-continuous at {w.water_cut_pct:g} % water cut, Brinkman emulsion.'
            elif wc >= est.INVERSION_WATER_CUT:
                mu, _ = est.mixture_viscosity_cp(0.0, mu_w, wc)
                basis = f'Water-continuous at {w.water_cut_pct:g} % water cut: water {mu_w:.2f} cP at {w.reservoir_temp_c:.0f} degC with the Brinkman emulsion factor. A tight emulsion is thicker.'
            else:
                raise ValueError('Viscosity cannot be estimated below 50 % water cut without the oil API gravity; please enter the viscosity or the API gravity.')
            fill('viscosity_cp', float(f'{mu:.3g}'), 'estimated', basis)
        if 'wellhead_temp' in todo:
            t_wh, relax = est.wellhead_temperature_c(w, api, surface_earth_temp_c)
            fill('wellhead_temp', round(_from_c(t_wh, unit('wellhead_temp_unit')), 0), 'estimated', f'Ramey / Hasan-Kabir heat loss up {w.pump_depth_ft:,.0f} ft of tubing at {w.desired_rate_bpd:,.0f} bpd (relaxation length {relax:,.0f} ft, surface earth {surface_earth_temp_c:g} degC).' + density_note)
        if 'gas_through_annulus_pct' in todo:
            e, vsl, v_inf = est.annulus_gas_pct(w, api)
            fill('gas_through_annulus_pct', round(e, 0), 'estimated', f'Alhanati natural separation: liquid rises past the intake at {vsl:.2f} m/s against a bubble rise of {v_inf:.2f} m/s. Assumes the intake is above the perforations.' + density_note)
    WellInputsAsEntered(**well).to_well_inputs()
    inputs = []
    for field, (label, unit_or_field) in FIELDS.items():
        if field == 'fluid_level' and has_inflow and _blank(raw_well.get('fluid_level')):
            continue
        source, basis = filled.get(field, ('given', ''))
        u = unit(unit_or_field) if unit_or_field.endswith('_unit') else unit_or_field
        inputs.append(InputSource(field=field, label=label, value=float(well[field]), unit=str(u), source=source, basis=basis))
    return Resolved(well=well, inputs=inputs, notes=notes)
