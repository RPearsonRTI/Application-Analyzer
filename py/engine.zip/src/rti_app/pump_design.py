from __future__ import annotations
import math
from functools import lru_cache
import numpy as np
from pydantic import BaseModel, Field
from scipy.optimize import brentq
from .catalog import PumpSpec, get_pump
M3D_PER_100RPM_PER_IN3 = 100.0 * 1440.0 * 0.0254 ** 3
IN3_PER_GAL = 231.0
LIFT_M_PER_STAGE = 35.0
R65_GEOMETRY = (2.0, 0.23, 1.06, 6.3)
ALPHA_REFERENCE = 'R65-1200'
SMALL_REFERENCE, LARGE_REFERENCE = ('R65-1200', 'R200-1300')
R200_GEOMETRY = (2.45, 0.45, 1.0, 6.0)
_T = np.linspace(0.0, 2.0 * math.pi, 1441)

def rotor_xy(t, r: float, e: float, o: float):
    k = np.sqrt(o ** 2 / (r ** 2 + e ** 2 - 2.0 * r * e * np.cos(2.0 * t)))
    return (-(r + e) * np.cos(t) + (r - e) * np.cos(t) * k, (r - e) * np.sin(t) - (r + e) * np.sin(t) * k)

def stator_xy(t, r: float, e: float, o: float):
    d = np.sqrt((e * np.cos(t) - r) ** 2 + (e * np.sin(t)) ** 2)
    radius = d - abs(o)
    phi = t + math.copysign(1.0, r) * np.arccos(np.clip(r * np.sin(t) / d, -1.0, 1.0))
    return (e * np.sin(t) - radius * np.cos(phi), -(e * np.cos(t) + radius * np.sin(phi)))

def _area(x, y) -> float:
    return 0.5 * abs(float(np.sum(x[:-1] * y[1:] - x[1:] * y[:-1])))

def areas(r: float, e: float, o: float) -> tuple[float, float]:
    return (_area(*rotor_xy(_T, r, e, o)), _area(*stator_xy(_T, r, e, o)))

def stage_offset(r: float, e: float) -> float:
    return 2.0 - math.acos(max(-1.0, min(1.0, e / r))) / math.pi

def rotor_curvature_radius(r: float, e: float, o: float, pitch: float) -> float:
    a = (r - e) ** 2 - abs(o) * abs(r + e)
    b = abs(r + e) - abs(o)
    if a * b <= 0.0:
        return 0.0
    k = pitch ** 2 * abs(r + e) + 4.0 * math.pi ** 2 * r * e * b
    return abs(2.0 * pitch ** 2 * a) / (abs(k) + math.sqrt(max(k * k - 16.0 * math.pi ** 2 * pitch ** 2 * r * e * a, 0.0)))

def stator_curvature_radius(r: float, e: float, o: float, pitch: float) -> float:
    k = pitch ** 2 + 4.0 * math.pi ** 2 * abs(r) * (abs(r) - abs(o))
    lobe = 2.0 * pitch ** 2 * abs(o) / (abs(k) + math.sqrt(k * k + 16.0 * math.pi ** 2 * pitch ** 2 * abs(r * o)))
    waist = abs(math.sqrt(max(r * r - e * e, 0.0)) - abs(o)) * math.sqrt(1.0 + (2.0 * math.pi * e / pitch) ** 2)
    return min(lobe, waist)

def seal_lengths(r: float, e: float, o: float, pitch: float, n: int=500) -> tuple[float, float, float]:
    if r < 0.0:
        r, e, o = (-r, -e, -o)
    t_tip = math.asin(math.sqrt(max(0.5 - e / (2.0 * r), 0.0)))

    def seal(t, theta) -> float:
        s = np.sqrt(r * r + e * e - 2.0 * r * e * np.cos(2.0 * t))
        x = -(r + e) * np.cos(t) + (r - e) * o * np.cos(t) / s
        y = (r - e) * np.sin(t) - (r + e) * o * np.sin(t) / s
        big_x = x * np.cos(theta) - y * np.sin(theta)
        big_z = -(x * np.sin(theta) + y * np.cos(theta) - e)
        axial = theta * pitch / math.pi
        return float(np.sum(np.sqrt(np.diff(big_x) ** 2 + np.diff(big_z) ** 2 + np.diff(axial) ** 2)))
    tip = np.linspace(-t_tip, t_tip, n + 1)
    base = np.linspace(t_tip, math.pi - t_tip, n + 1)
    major = seal(tip, tip + 2.0 * np.arctan((r + e) / (r - e) * np.tan(tip)) + math.pi / 2.0)
    tip_minor = seal(tip, -tip - math.pi / 2.0)
    base_minor = seal(base, -base - math.pi / 2.0)
    return (major, tip_minor, base_minor)

def effective_contact_length(r: float, e: float, o: float, pitch: float) -> float:
    major, tip_minor, base_minor = seal_lengths(r, e, o, pitch)
    return major + tip_minor + 2.0 * base_minor

def total_contact_length(r: float, e: float, o: float, pitch: float) -> float:
    return sum(seal_lengths(r, e, o, pitch))

def from_sharpness(a: float, b: float, s: float) -> tuple[float, float, float]:
    d = (a - b) ** 2 - s * b * b
    e = (a - b) / 2.0
    o = s * a * b * b / d
    return (o + (a + b) / 2.0, e, o)

class DesignRequest(BaseModel):
    displacement_m3d_per_100rpm: float = Field(gt=0, le=2000)
    rated_lift_m: float = Field(gt=0, le=6000)
    length_in: float = Field(default=220.0, gt=0, le=1000)
    min_stator_minor_in: float = Field(default=1.88, gt=0, le=20)
    wall_in: float = Field(default=0.4, ge=0, le=5)
    min_curvature_in: float = Field(default=0.1, ge=0, le=5)
    max_stator_od_in: float | None = Field(default=None, gt=0)

class PumpDesign(BaseModel):
    name: str
    r_in: float
    e_in: float
    o_in: float
    pitch_in: float
    rotor_major_in: float
    rotor_minor_in: float
    sharpness: float
    stator_minor_in: float
    stator_major_in: float
    stator_od_in: float
    max_stator_od_in: float | None
    fits: bool | None
    length_in: float
    stages: float
    stage_offset: float
    rated_lift_m: float
    rotor_area_in2: float
    flux_area_in2: float
    displacement_m3d_per_100rpm: float
    gal_per_rev: float
    rotor_curvature_in: float
    stator_curvature_in: float
    contact_length_in: float
    total_contact_length_in: float
    total_contact_in: float
    alpha: float
    beta1: float
    epsilon: float
    gamma: float
    basis: list[str]
    notes: list[str]
    rotor_outline: list[tuple[float, float]]
    stator_outline: list[tuple[float, float]]

    def to_pump_spec(self) -> PumpSpec:
        return PumpSpec(model=self.name, series='Design', length_in=self.length_in, gal_per_rev=self.gal_per_rev, stage_pitch_in=self.pitch_in, stage_offset=self.stage_offset, alpha=self.alpha, beta1=self.beta1, epsilon=self.epsilon, gamma=self.gamma, flux_area_in2=self.flux_area_in2, rotor_area_in2=self.rotor_area_in2)

def _state(a: float, minor: float, s: float, stages: float, length: float):
    r, e, o = from_sharpness(a, minor - a, s)
    if not all(map(math.isfinite, (r, e, o))) or abs(e) >= abs(r):
        return None
    pitch = length / (stages + stage_offset(r, e))
    rotor, stator = areas(r, e, o)
    return (r, e, o, pitch, (stator - rotor) * pitch * 2.0 * M3D_PER_100RPM_PER_IN3)

def _solve_at_minor(target: float, minor: float, stages: float, length: float, min_curvature: float=0.0):
    lo, hi = (minor / 2.0 * 1.001, minor * 0.995)

    def a_for(s: float):

        def miss(a: float) -> float:
            st = _state(a, minor, s, stages, length)
            return float('nan') if st is None else st[4] - target
        grid = np.linspace(lo, hi, 4)
        vals = [miss(a) for a in grid]
        for a0, a1, v0, v1 in zip(grid, grid[1:], vals, vals[1:]):
            if math.isfinite(v0) and math.isfinite(v1) and (v0 < 0.0 <= v1):
                try:
                    return brentq(miss, a0, a1, xtol=1e-06)
                except ValueError:
                    return None
        return None

    def curvature_gap(s: float) -> float:
        a = a_for(s)
        if a is None:
            return float('nan')
        r, e, o, pitch, _ = _state(a, minor, s, stages, length)
        return rotor_curvature_radius(r, e, o, pitch) - stator_curvature_radius(r, e, o, pitch)
    grid = np.linspace(0.01, 0.99, 9)
    prev_s, prev_g = (None, float('nan'))
    for s in grid:
        g = curvature_gap(float(s))
        if prev_s is not None and prev_g > 0.0 >= g:
            try:
                root = brentq(curvature_gap, prev_s, float(s), xtol=0.0001)
            except ValueError:
                return None
            a = a_for(root)
            if a is None:
                return None
            r, e, o, pitch, _ = _state(a, minor, root, stages, length)
            return (root, a) if rotor_curvature_radius(r, e, o, pitch) >= min_curvature else None
        prev_s, prev_g = (float(s), g)
    return None

@lru_cache(maxsize=512)
def _design(target: float, lift_m: float, length: float, min_minor: float, wall: float, max_od: float | None, min_curvature: float=0.1) -> PumpDesign:
    stages = lift_m / LIFT_M_PER_STAGE
    minor, lo, step = (min_minor, min_minor, 0.05)
    found = _solve_at_minor(target, minor, stages, length, min_curvature)
    while found is None and minor < min_minor + 6.0:
        lo, minor, step = (minor, minor + step, min(step * 2.0, 0.8))
        found = _solve_at_minor(target, minor, stages, length, min_curvature)
    if found is None:
        raise ValueError(f'No cross-section gives {target:g} m3/d per 100 RPM with {stages:.1f} stages in {length:g} in while keeping the rotor and stator curvature equal and at least {min_curvature:g} in. Try a longer pump or a lower rated lift.')
    if minor > min_minor:
        hi = minor
        for _ in range(6):
            mid = 0.5 * (lo + hi)
            trial = _solve_at_minor(target, mid, stages, length, min_curvature)
            if trial is None:
                lo = mid
            else:
                hi, found = (mid, trial)
        minor = hi
    s, a = found
    r, e, o, pitch, disp = _state(a, minor, s, stages, length)
    rotor_area, stator_area = areas(r, e, o)
    sx, sy = stator_xy(_T, r, e, o)
    stator_major = 2.0 * float(np.max(np.hypot(sx, sy)))
    od = stator_major + 2.0 * wall
    gpr = (stator_area - rotor_area) * pitch * 2.0 / IN3_PER_GAL
    ecl = effective_contact_length(r, e, o, pitch)
    real = total_contact_length(r, e, o, pitch)
    n_stages = length / pitch - stage_offset(r, e)
    contact = real * n_stages
    ref = get_pump(ALPHA_REFERENCE)
    k_seal = ref.alpha / effective_contact_length(*R65_GEOMETRY)
    small, large = (get_pump(SMALL_REFERENCE), get_pump(LARGE_REFERENCE))
    w = min(max((gpr - small.gal_per_rev) / (large.gal_per_rev - small.gal_per_rev), 0.0), 1.0)
    where = 'as the R65' if w < 0.005 else 'as the R200' if w > 0.995 else f'{w:.0%} of the way from the R65 to the R200 by displacement'
    beta1 = (1.0 - w) * small.beta1 + w * large.beta1
    c_small = total_contact_length(*R65_GEOMETRY) * small.stages
    c_large = total_contact_length(*R200_GEOMETRY) * large.stages
    eps_per_in = (1.0 - w) * small.epsilon / c_small + w * large.epsilon / c_large
    gamma_per_in = (1.0 - w) * small.gamma / c_small + w * large.gamma / c_large
    epsilon, gamma = (eps_per_in * contact, gamma_per_in * contact)
    basis = [f'Slip coefficient alpha = {k_seal * ecl:.2f}: proportional to the effective contact length per stage ({ecl:.1f} in), at {k_seal:.3f} gpm/in from the {ALPHA_REFERENCE}.', f'Friction torque (epsilon {epsilon:.3f} ft.lb/psi, gamma {gamma:.0f} ft.lb) scaled by the total real contact, {real:.1f} in per stage x {n_stages:.1f} stages = {contact:,.0f} in, with the friction per inch taken {where} (R65-1200: {c_small:,.0f} in, R200-1300: {c_large:,.0f} in).', f'Slip exponent beta1 {beta1:.2f} taken {where}. No pump of this size has been tested.', f'Rated at {LIFT_M_PER_STAGE:g} m (50 psi) per stage: {stages:.1f} stages for {lift_m:g} m.']
    notes = []
    if minor > min_minor + 1e-06:
        notes.append(f'The stator minor diameter had to grow from {min_minor:g} to {minor:.2f} in to keep the rotor and stator curvatures equal and at least {min_curvature:g} in.')
    if r < 0.0:
        notes.append('R and O are negative for this shape (sharpness past the D = 0 point); the contact length uses (-R, -E, -O).')
    fits = None if max_od is None else od <= max_od
    if fits is False:
        notes.append(f'Stator OD {od:.2f} in (with a {wall:g} in wall) is larger than the {max_od:g} in available.')
    step = 8
    return PumpDesign(name=f'R{disp:.0f}-{lift_m:.0f} design', r_in=r, e_in=e, o_in=o, pitch_in=pitch, rotor_major_in=2.0 * a, rotor_minor_in=2.0 * (minor - a), sharpness=s, stator_minor_in=minor, stator_major_in=stator_major, stator_od_in=od, max_stator_od_in=max_od, fits=fits, length_in=length, stages=length / pitch - stage_offset(r, e), stage_offset=stage_offset(r, e), rated_lift_m=lift_m, rotor_area_in2=rotor_area, flux_area_in2=stator_area - rotor_area, displacement_m3d_per_100rpm=disp, gal_per_rev=gpr, rotor_curvature_in=rotor_curvature_radius(r, e, o, pitch), stator_curvature_in=stator_curvature_radius(r, e, o, pitch), contact_length_in=ecl, total_contact_length_in=real, total_contact_in=contact, alpha=k_seal * ecl, beta1=beta1, epsilon=epsilon, gamma=gamma, basis=basis, notes=notes, rotor_outline=[(float(x), float(y)) for x, y in zip(*(c[::step] for c in rotor_xy(_T, r, e, o)))], stator_outline=[(float(x), float(y)) for x, y in zip(sx[::step], sy[::step])])

def design_pump(req: DesignRequest) -> PumpDesign:
    return _design(req.displacement_m3d_per_100rpm, req.rated_lift_m, req.length_in, req.min_stator_minor_in, req.wall_in, req.max_stator_od_in, req.min_curvature_in)

class OptimizeResult(BaseModel):
    design: DesignRequest
    efficiency: float
    rpm: float
    dp_psi: float
    pressure_loading: float
    speed_loading: float
    evaluated: int
    feasible: int
    notes: list[str]

def optimize_design(well, options=None, *, alpha_override: float | None=None, length_in: float=220.0, min_stator_minor_in: float=1.88, wall_in: float=0.4, max_stator_od_in: float | None=None, min_curvature_in: float=0.1) -> OptimizeResult:
    from scipy.optimize import minimize
    from .operating_point import solve_operating_point
    from .units import BPD_PER_M3D, GPM_PER_BPD
    q_gpm = well.desired_rate_bpd * GPM_PER_BPD
    q_m3d = well.desired_rate_bpd / BPD_PER_M3D
    probe = solve_operating_point(well, get_pump(LARGE_REFERENCE), options=options)
    if probe.dp_psi <= 0.0:
        raise ValueError('The well flows without a pump at this operating point (no differential pressure); there is nothing to optimise.')
    lift_min = probe.dp_psi / get_pump(LARGE_REFERENCE).rated_dp_per_stage_psi * LIFT_M_PER_STAGE * 1.002
    counts = {'evaluated': 0, 'feasible': 0}

    def evaluate(disp: float, lift: float):
        counts['evaluated'] += 1
        if disp <= 0.0 or lift < lift_min:
            return None
        try:
            d = _design(round(disp, 3), round(lift, 2), length_in, min_stator_minor_in, wall_in, max_stator_od_in, min_curvature_in)
            op = solve_operating_point(well, d.to_pump_spec(), alpha_override=alpha_override, options=options)
        except (ValueError, ZeroDivisionError, FloatingPointError):
            return None
        shaft_hp = op.torque_ftlb * op.rpm / 5252.0
        if d.fits is False or op.pressure_loading > 1.0 or op.speed_loading > 1.0 or (shaft_hp <= 0.0) or (not math.isfinite(shaft_hp)):
            return None
        counts['feasible'] += 1
        return (q_gpm * op.dp_psi / 1714.0 / shaft_hp, op)
    best = None
    for disp in np.geomspace(q_m3d / 4.0, q_m3d * 2.5, 8):
        for factor in (1.0, 1.15, 1.4, 1.8, 2.3):
            got = evaluate(float(disp), lift_min * factor)
            if got is not None and (best is None or got[0] > best[0]):
                best = (got[0], float(disp), lift_min * factor)
    if best is None:
        raise ValueError(f'No design in {length_in:g} in keeps this well within 50 psi per stage and 400 RPM' + (f' with a stator OD under {max_stator_od_in:g} in' if max_stator_od_in else '') + '. Try a longer pump.')

    def cost(x) -> float:
        got = evaluate(math.exp(x[0]), max(x[1], lift_min))
        return 1.0 if got is None else -got[0]
    res = minimize(cost, [math.log(best[1]), best[2]], method='Nelder-Mead', options={'maxfev': 30, 'xatol': 0.01, 'fatol': 0.0001, 'initial_simplex': [[math.log(best[1]), best[2]], [math.log(best[1] * 1.12), best[2]], [math.log(best[1]), best[2] * 1.06]]})
    if -res.fun > best[0]:
        best = (-res.fun, math.exp(res.x[0]), max(res.x[1], lift_min))
    disp, lift = (round(best[1], 1), math.ceil(best[2]))
    eff, op = evaluate(disp, lift) or evaluate(best[1], best[2])
    notes = []
    if lift <= lift_min * 1.01:
        notes.append('The rated lift is at its minimum: the pump runs at its rating of 50 psi per stage. More stages would cut slip but add more friction than they save.')
    if op.speed_loading > 0.95:
        notes.append('The speed is at the 400 RPM rating.')
    return OptimizeResult(design=DesignRequest(displacement_m3d_per_100rpm=disp, rated_lift_m=lift, length_in=length_in, min_stator_minor_in=min_stator_minor_in, wall_in=wall_in, max_stator_od_in=max_stator_od_in, min_curvature_in=min_curvature_in), efficiency=eff, rpm=op.rpm, dp_psi=op.dp_psi, pressure_loading=op.pressure_loading, speed_loading=op.speed_loading, evaluated=counts['evaluated'], feasible=counts['feasible'], notes=notes)
